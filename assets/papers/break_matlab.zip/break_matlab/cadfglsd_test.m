% cadfglsd.m
%
% Implements unit root tests discussed in:
%
% Fossati, S. (2009): "Unit Root Testing with Statioanry Covariates and a 
% Structural Break in the Trend Function", working paper. 
%
% Inputs:   
%           yt      - a Tx1 vector of potentially stationary variables
%           Xt      - a Txm matrix of covariates
%           order   - order of integration of the covariates: 0 for I(0), 
%                                                             1 for I(1)
%           p       - the case number indexing the deterministic component
%           model   - a for break in the intercept, b for break in the
%                   slope, and c for both
%           penalty - 0 for MAIC/MAIC, 1 for BIC, 2 for AIC, 3 for MBIC, 4
%           for MAIC  
%           kmax    - maximum number of leads/lags terms
%           kmin    - minimum number of leads/lags terms
%
% Output:
%
%           
% Written by:
% Sebastian Fossati
% Dept of Economics
% University of Washington


function [results] = cadfglsd_test(yt,Xt,order,p,model,penalty,kmax,kmin)
% yt and Xt are of size T
% Xt is I(0) or I(1)

warning off all;

PRINT = 1;

% results [tstat,bhat,R2,kopt,Td,tstata];
[tests,tests_all] = cadfgls_delta_test(yt,Xt,order,p,model,penalty,kmax,kmin);


% Critical values
if (model=='a')
    
    line = p - 1;

    sup01_100 = [-3.033,-3.007,-3.028,-3.021,-3.015,-2.952,-2.988,-2.947,-2.890,-2.835; ...
                 -3.031,-2.995,-2.993,-2.952,-2.915,-2.827,-2.829,-2.732,-2.663,-2.570; ...
                 -3.863,-3.791,-3.761,-3.710,-3.662,-3.574,-3.505,-3.434,-3.257,-3.125; ...
                 -3.864,-3.780,-3.744,-3.675,-3.627,-3.524,-3.434,-3.352,-3.171,-3.045];
                 
    sup05_100 = [-2.452,-2.445,-2.438,-2.409,-2.398,-2.353,-2.338,-2.313,-2.245,-2.203; ...
                 -2.448,-2.419,-2.384,-2.334,-2.293,-2.225,-2.158,-2.073,-1.992,-1.916; ...
                 -3.264,-3.222,-3.167,-3.099,-3.046,-2.961,-2.875,-2.766,-2.640,-2.498; ...
                 -3.261,-3.206,-3.145,-3.058,-2.995,-2.906,-2.800,-2.667,-2.518,-2.362];
                 
    sup10_100 = [-2.163,-2.149,-2.141,-2.097,-2.083,-2.044,-2.015,-1.966,-1.914,-1.859; ...
                 -2.159,-2.124,-2.080,-2.018,-1.968,-1.901,-1.834,-1.735,-1.639,-1.539; ...
                 -2.983,-2.926,-2.869,-2.796,-2.730,-2.644,-2.550,-2.430,-2.295,-2.164; ...
                 -2.980,-2.915,-2.838,-2.758,-2.676,-2.584,-2.456,-2.325,-2.167,-2.001];
               
    sup01_250 = [-2.825,-2.829,-2.816,-2.821,-2.822,-2.814,-2.806,-2.779,-2.736,-2.690; ...
                 -2.821,-2.816,-2.777,-2.754,-2.708,-2.664,-2.638,-2.559,-2.482,-2.417; ...
                 -3.594,-3.568,-3.544,-3.471,-3.445,-3.373,-3.314,-3.230,-3.085,-2.973; ...
                 -3.592,-3.555,-3.518,-3.430,-3.394,-3.295,-3.239,-3.142,-2.987,-2.853];
                 
    sup05_250 = [-2.262,-2.251,-2.241,-2.208,-2.200,-2.198,-2.167,-2.126,-2.104,-2.040; ...
                 -2.259,-2.221,-2.183,-2.123,-2.076,-2.047,-1.970,-1.894,-1.800,-1.691; ...
                 -3.061,-3.006,-2.957,-2.903,-2.848,-2.766,-2.696,-2.598,-2.481,-2.362; ...
                 -3.062,-2.996,-2.933,-2.867,-2.792,-2.685,-2.607,-2.481,-2.334,-2.164];
                 
    sup10_250 = [-1.961,-1.949,-1.925,-1.899,-1.880,-1.865,-1.827,-1.796,-1.755,-1.701; ...
                 -1.960,-1.919,-1.867,-1.810,-1.749,-1.695,-1.607,-1.544,-1.429,-1.303; ...
                 -2.785,-2.719,-2.660,-2.597,-2.544,-2.455,-2.367,-2.278,-2.163,-2.035; ...
                 -2.784,-2.708,-2.632,-2.552,-2.478,-2.367,-2.261,-2.143,-1.986,-1.799];
                 
elseif (model=='b')
    
    line = p - 3;
    
    sup01_100 = [-4.657,-4.570,-4.467,-4.389,-4.263,-4.129,-4.030,-3.882,-3.660,-3.525; ...
                 -4.654,-4.559,-4.461,-4.382,-4.250,-4.109,-4.004,-3.860,-3.624,-3.463];
    
    sup05_100 = [-4.072,-3.960,-3.864,-3.758,-3.642,-3.493,-3.354,-3.172,-2.951,-2.726; ...
                 -4.073,-3.960,-3.861,-3.751,-3.631,-3.483,-3.339,-3.152,-2.926,-2.679];

    sup10_100 = [-3.770,-3.662,-3.558,-3.440,-3.315,-3.167,-3.012,-2.822,-2.597,-2.335; ...
                 -3.770,-3.661,-3.555,-3.434,-3.309,-3.165,-2.996,-2.800,-2.571,-2.299];
                 
    sup01_250 = [-4.453,-4.390,-4.332,-4.219,-4.142,-4.039,-3.894,-3.772,-3.666,-3.672; ...
                 -4.451,-4.385,-4.327,-4.202,-4.123,-4.002,-3.864,-3.714,-3.573,-3.458];
    
    sup05_250 = [-3.916,-3.828,-3.735,-3.630,-3.530,-3.409,-3.261,-3.106,-2.950,-2.804; ...
                 -3.916,-3.828,-3.727,-3.619,-3.517,-3.389,-3.243,-3.076,-2.879,-2.691];
    
    sup10_250 = [-3.641,-3.538,-3.441,-3.330,-3.217,-3.075,-2.925,-2.746,-2.570,-2.370; ...
                 -3.640,-3.537,-3.438,-3.323,-3.211,-3.056,-2.909,-2.725,-2.527,-2.294];
                              
elseif (model=='c')
    
    line = p - 3;
    
    sup01_100 = [-4.627,-4.518,-4.449,-4.365,-4.255,-4.140,-4.041,-3.911,-3.746,-3.537; ...
                 -4.628,-4.508,-4.439,-4.353,-4.239,-4.130,-4.000,-3.867,-3.657,-3.424];
                 
    sup05_100 = [-4.043,-3.942,-3.857,-3.755,-3.651,-3.513,-3.375,-3.211,-3.022,-2.791; ...
                 -4.041,-3.938,-3.851,-3.741,-3.644,-3.496,-3.358,-3.176,-2.976,-2.720];
    
    sup10_100 = [-3.747,-3.658,-3.553,-3.445,-3.337,-3.196,-3.043,-2.864,-2.664,-2.414; ...
                 -3.747,-3.656,-3.549,-3.438,-3.322,-3.181,-3.023,-2.831,-2.628,-2.356];

    sup01_250 = [-4.379,-4.324,-4.277,-4.197,-4.112,-4.008,-3.898,-3.809,-3.713,-3.696; ...
                 -4.380,-4.328,-4.259,-4.173,-4.083,-3.985,-3.856,-3.731,-3.570,-3.449];
                 
    sup05_250 = [-3.850,-3.778,-3.700,-3.614,-3.513,-3.395,-3.276,-3.133,-2.989,-2.859; ...
                 -3.849,-3.777,-3.693,-3.597,-3.496,-3.372,-3.235,-3.091,-2.911,-2.716];
    
    sup10_250 = [-3.588,-3.502,-3.413,-3.312,-3.206,-3.077,-2.938,-2.779,-2.615,-2.441; ...
                 -3.587,-3.499,-3.408,-3.300,-3.192,-3.051,-2.913,-2.745,-2.557,-2.344];
                 
end

% Get supremum critical values
R2 = tests(1,3);
if R2 <= 0
    critvals_sup = [sup01_100(line,1),sup05_100(line,1),sup10_100(line,1); ...
                    sup01_250(line,1),sup05_250(line,1),sup10_250(line,1)];
elseif (R2 < 0.90) & (R2 > 0)
    R2index = 1 + floor(10*R2);
    R2weight = rem(10*R2,1);
    cv_sup_below = [sup01_100(line,R2index),sup05_100(line,R2index),sup10_100(line,R2index); ...
                    sup01_250(line,R2index),sup05_250(line,R2index),sup10_250(line,R2index)];
    cv_sup_above = [sup01_100(line,R2index+1),sup05_100(line,R2index+1),sup10_100(line,R2index+1); ...
                    sup01_250(line,R2index+1),sup05_250(line,R2index+1),sup10_250(line,R2index+1)];
    critvals_sup = cv_sup_below + R2weight.*(cv_sup_above - cv_sup_below);
else
    critvals_sup = [sup01_100(line,10),sup05_100(line,10),sup10_100(line,10); ...
                   sup01_250(line,10),sup05_250(line,10),sup10_250(line,10)];
end

% Results
results.tests = tests;
results.tests_all = tests_all;
results.critvals_sup = critvals_sup;

% tests = [tstat,bhat,R2,kopt,Td,tstata];
if (PRINT==1),
    disp(' ');
    disp('--------------------------------------------------');
    disp(' Test: Fossati (2008)                             ');
    disp('--------------------------------------------------');
    disp('--------------------------------------------------');
    disp(' Supremum Test Statistic                           ');
    disp('--------------------------------------------------');
    fprintf('t-stat: %f\n',tests(1,1))
    fprintf('Critical Values T = 100: \t %6.2f \t %6.2f \t %6.2f\n', ...
                critvals_sup(1,1),critvals_sup(1,2),critvals_sup(1,3));
    fprintf('Critical Values T = 250: \t %6.2f \t %6.2f \t %6.2f\n', ...
                critvals_sup(2,1),critvals_sup(2,2),critvals_sup(2,3));
    fprintf('Estimated Coefficient: %6.4f\n',tests(1,2)+1)
    fprintf('Estimated R2: %6.4f\n',tests(1,3))
    fprintf('Deterministic Case: %d %s\n',p,model)
    fprintf('dy(t) lag order: %d\n',tests(1,4))
    fprintf('X(t) lead order: %d\n',tests(1,6))
    fprintf('X(t) lag order: %d\n',tests(1,5))
    fprintf('Break Date: %d\n',tests(1,7))
    disp('--------------------------------------------------');
end

return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [results,tmp] = cadfgls_delta_test(yt,Xt,order,p,model,penalty,kmax,kmin)
T = size(yt,1);
jstart = 1;
jend = T;
tmp = zeros(T,8);
for j=jstart:jend
    delta = j/T;
    % results [tstat,bhat,R2,kopt,Td,tstata];
    cadf = cadfglstest(yt,Xt,order,p,model,penalty,kmax,kmin,delta);
    tmp(j,:) = cadf;
end
% Get inf
[junk pos] = min(tmp(:,1),[],1);
cadfinf = tmp(pos,:);
% Get sup
tmp2 = abs(tmp(floor(.15*T):ceil(.85*T),8));
[junk pos2] = min(-tmp2,[],1);
cadfsup = tmp(pos2+floor(.15*T)-1,:);
% Results
results = [cadfsup;cadfinf];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [results] = cadfglstest(yt,Xt,order,p,model,penalty,kmax,kmin,delta)
T = size(yt,1);
m = size(Xt,2);
Td = delta*T;
trend = (1:1:T)';
indic = (trend>Td);
% Get cbar
if (p<4),
    cbar = -7;
else
    if (model=='a'), 
        cbar = -13.5; 
    else, 
        cbar = -22.5; 
    end
end
% Get deterministic component
if (p==2), 
    zy = [ones(T,1),indic]; 
elseif (p==3),
    zy = [ones(T,1),indic];
    zx = [ones(T,1)]; 
elseif (p==4),
    if (model=='a'), zy = [ones(T,1),indic,trend]; end;
    if (model=='b'), zy = [ones(T,1),trend,indic.*(trend-Td)]; end;
    if (model=='c'), zy = [ones(T,1),indic,trend,indic.*(trend-Td)]; end;    
    zx = [ones(T,1)]; 
elseif (p==5),
    if (model=='a'), zy = [ones(T,1),indic,trend]; end;
    if (model=='b'), zy = [ones(T,1),trend,indic.*(trend-Td)]; end;
    if (model=='c'), zy = [ones(T,1),indic,trend,indic.*(trend-Td)]; end;    
    zx = [ones(T,1),trend]; 
end
% Step 1
% Transform the data 
[yt, bhat, tstat, ssr] = glsd(yt,zy,cbar);
% Select t-stat
if (model=='a'), tstata = tstat(2,1); end;
if (model=='b'), tstata = tstat(3,1); end;
if (model=='c'), tstata = tstat(4,1); end;
% Step 2
% Transform the data
if (order==0), dXt = Xt; end;
if (order==1), dXt = diffk(Xt,1); end;
if (p>2), [dXt] = olsd(dXt,zx); end;

% Get optimal number of lags
krule = s2ar(yt,kmax,kmin);
if penalty==0
    tmp = optlags(yt,dXt,krule(1,4),kmin); % send k(maic) and get [k1,k2,k3]
    KOPT = tmp(4,:);
else
    KOPT = [krule(1,penalty),krule(1,penalty),krule(1,penalty)];
end
% Get test results
% results = [tstat,bhat(1),R2,kopt];
cadf = cadfglsmain(yt,dXt,p,KOPT);
% Results [tstat,bhat,R2,kopt,Td,tstata];
results = [cadf Td tstata];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [results] = cadfglsmain(yt,dXt,p,kopt)
nt = size(yt,1);
m = size(dXt,2);
k1 = kopt(1);
k2 = kopt(2);
k3 = kopt(3);
% Generate regressors
dyt = diffk(yt,1);
reg = lagn(yt,1);
for i=1:k1, reg = [reg lagn(dyt,i)]; end
reg = [reg dXt];
for i=1:k2, reg = [reg lagn(dXt,i)]; end
for i=1:k3, reg = [reg lagn(dXt,-i)]; end
% Trim sample
dyt = trimr(dyt,max(k1,k2)+1,k3);
reg = trimr(reg,max(k1,k2)+1,k3);
% Run regression
invREG2 = inv(reg'*reg);
bhat = invREG2*reg'*dyt;
ehat = dyt - reg*bhat;
% Effective number of observation adjusted for degrees of freedom
N = size(dyt,1)-1-k1-(1+k2+k3)*m;
% N = size(dyt,1)-1-k1-(1+k2+k3)*m;
sigma2=(ehat'*ehat)/N;
Covar = invREG2*sigma2;
se = sqrt(diag(Covar));
tstat = bhat(1)/se(1);
vhat = ehat + reg(:,2+k1:length(reg(1,:)))*bhat(2+k1:length(reg(1,:)));
[omega,bandw] = lr_var([vhat,ehat]);
R2=1-(omega(2,1)^2)/(omega(1,1)*omega(2,2));
results = [tstat,bhat(1),R2,kopt];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [kopt] = optlags(yt,dXt,kmax,kmin)
% 
nt = size(yt,1);
m = size(dXt,2);
tau = zeros((kmax+1)^3,1);
s2e = 999999*ones((kmax+1)^3,1);
dyt = diffk(yt,1);

reg = lagn(yt,1);
for i=1:kmax, reg = [reg lagn(dyt,i)]; end
reg = [reg dXt];
for i=1:kmax, reg = [reg lagn(dXt,i)]; end
for i=1:kmax, reg = [reg lagn(dXt,-i)]; end

% Trim sample
dyt0 = trimr(dyt,kmax+1,kmax);
reg0 = trimr(reg,kmax+1,kmax);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-2*kmax-1;

regy = reg0(:,1:1+kmax);
regx = reg0(:,1+kmax+1:1+kmax+m);
regxlag = reg0(:,1+kmax+m+1:1+kmax+m+kmax*m);
regxlead = reg0(:,1+kmax+m+kmax*m+1:1+kmax+m+2*kmax*m);

ks = zeros((kmax+1)^3,3);
ii = kmin+1;
for k1=kmin:kmax
    for k2=kmin:kmax
        for k3=kmin:kmax
            ks(ii,:) = [k1,k2,k3];
            reg1 = [regy(:,1:1+k1),regx,regxlag(:,1:k2*m),regxlead(:,1:k3*m)];
            b = reg1\dyt0;
            e = dyt0-reg1*b;
            s2e(ii) = e'*e/nef;
            tau(ii) = (b(1)*b(1))*sumy/s2e(ii);
            ii = ii+1;
        end
    end
end

kk = 1+ks(:,1)+(1+ks(:,2)+ks(:,3))*m;
ic(:,1) = log(s2e) + log(nef)*(kk)./nef;
ic(:,2) = log(s2e) + 2*(kk)./nef;
ic(:,3) = log(s2e) + log(nef)*(kk+tau)./nef;
ic(:,4) = log(s2e) + 2*(kk+tau)./nef;
[junk Iic] = min(ic,[],1);
kopt = ks(Iic,:);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Non-parametric estimation of the long-run variance.
% Adapted from Bruce Hansen's Gauss function urreg.pcr.
function [omega,bandw] = lr_var(e)
kernel  = 1;
band    = 0;
[T,p] = size(e);
% Determine bandwidth following Andrews (1991)
if band==0
    elag = e(1:T-1,:);
    et = e(2:T,:);
    % Estimate AR(1) models for each column
    ae = sum(elag.*et)'./sum(elag.^2)';
    ee = et-elag.*(ones(T-1,1)*ae');
    se = mean(ee.^2)';
    % Intermediate calculations
    ad = sum((se./((1-ae).^2)).^2)';
    aese = ae.*se;
    a1 = 4*sum((aese./((((1-ae).^3).*(1+ae))*ones(1,length(aese(1,:))))).^2)'/ad;
    a2 = 4*sum((aese./(((1-ae).^4)*ones(1,length(aese(1,:))))).^2)'/ad;
    if kernel==2
        bandw = 1.3221*((a2*T)^.2);     % Quadratic Spectral
    elseif kernel==1
        bandw = 2.6614*((a2*T)^.2);     % Parzen
        if bandw>(T-2), bandw = T-2; end
    elseif kernel==3;                   % Bartlett
        bandw = 1.1447*((a1*T)^.333);
        if bandw>(T-2), bandw = T-2; end
    end
else
    bandw = band;
end
% Get weights      
if kernel==2            % Quadratic Spectral Kernel
    N = T-1;
    di = ((1:N)./bandw)';
    mi = 1.2*pi*di;
    kern = 25*( (sin(mi)./mi - cos(mi) )./( (di.^2).*12*pi^2 ));
elseif kernel==1        % Parzen kernel
    N = T-1;
    bT = floor(bandw);
    if  bT<=0
        kern = zeros(N,1);
    else
        ai = ((1:N)./bandw)';
        kern = (1-6*(ai.^2)+6*(ai.^3)).*(ai<=.5);
        kern = kern + (2*(1-ai).^3).*(ai>.5);
        kern = kern.*(ai<=1);
    end;
elseif kernel==3        % Bartlett kernel
    N = T-1;
    bT = floor(bandw);
    if bT<=0
        kern = zeros(N,1);
    else
        ai = ((1:N)./bandw)';
        kern = (1-ai).*(ai<=1);
    end
end
% Estimate Covariances
tmp = zeros(p,p);
for i=1:N
    kj = kern(i);
    tmp = tmp + (e(1:T-i,:)'*e(1+i:T,:))*kj;
end
omega = (e'*e + tmp + tmp')/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kopt = s2ar(yts,kmax,kmin)
nt = size(yts,1);
tau = zeros(kmax+1,1);
s2e = 999999*ones(kmax+1,1);
dyts = diffk(yts,1);
reg = lagn(yts,1);
for i=1:kmax, reg = [reg lagn(dyts,i)]; end
dyts0 = dyts;
reg0 = reg;
dyts0 = trimr(dyts,kmax+1,0);
reg0 = trimr(reg,kmax+1,0);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-kmax-1;
for k=kmin:kmax
    b = reg0(:,1:k+1)\dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
end 
kk = 0:1:kmax;
ic(:,1) = log(s2e)+log(nef)*(kk')./nef;
ic(:,2) = log(s2e)+2*(kk')./nef;
ic(:,3) = log(s2e) + log(nef)*(kk'+tau)./nef;
ic(:,4) = log(s2e) + 2*(kk'+tau)./nef;
[junk Iic] = min(ic,[],1);
kopt = [Iic-1];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [yt, bhat, tstat, ssr] = glsd(y,z,cbar)
nt = size(y,1);
abar = 1 + cbar/nt;
ya = zeros(nt,1);
za = zeros(nt,size(z,2));
ya(1,1) = y(1,1);
za(1,:) = z(1,:);
ya(2:nt,1) = y(2:nt,1)-abar*y(1:nt-1,1);
za(2:nt,:) = z(2:nt,:)-abar*z(1:nt-1,:);
% Constructing the GLS detrended series
bhat = za\ya;                          
yt = y-z*bhat;
ssr = (ya-za*bhat)'*(ya-za*bhat);
% Computing t-stat
s2 = ssr/(nt-size(za,2));
varmat = s2*inv(za'*za);
tmp = sqrt(varmat);
tstat = bhat./diag(tmp);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Xd] = olsd(X,z)
bhat = z\X;                          
Xd = X - z*bhat;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = lagn(x,n)
ncol = size(x,2);
if n<0, y = [trimr(x,abs(n),0); zeros(abs(n),ncol)]; return, end 
y = [zeros(n,ncol); trimr(x,0,n)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = trimr(x,n1,n2)
n = size(x,1);
start = n1+1;   
finish = n-n2;
y = x(start:finish,:);
return;
