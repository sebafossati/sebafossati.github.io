% ejurtest.m
%
% Implements unit root tests discussed in:
%
% Elliot, G., and M. Jansson (2003): "Testing for Unit Roots with Sationary
% Covariates", Journal of Econometrics, 115, 75-89.
%
% Fossati, S. (2008): "Covariate Unit Root Tests with Good Size and Power",
% working paper. 
%
% Inputs:   
%           yt      - a Tx1 vector of potentially stationary variables
%           Xt      - a Txm matrix of I(1) covariates
%           p       - the case number indexing the deterministic component
%           penalty - 0 for univariate MAIC, 1 for BIC, 2 for AIC, 3 for
%                     MBIC, 4 for MAIC.
%           kmax    - maximum order of the VAR polynomial A(L)
%           kmin    - minimum order of the VAR polynomial A(L)
%
% Output:
%           LAMBDA  - the point optimal unit root test using covariates
%           Critval - the 5% critical value
%           R2hat   - the estimated R^2
%           kopt    - selected number of lags
%           
% ---------------------------------------------------------
% Adapted after Micheal Jansson's unitroot.m function
% ---------------------------------------------------------
%
% Written by:
% Sebastian Fossati
% Dept of Economics
% University of Washington

function [results] = ej_test(yt,Xt,p,penalty,kmax,kmin)
% yt and Xt (series in levels) are of size T
% Xt is I(1)
% results = [LAMBDA,Critval,R2hat,kopt]

T = size(yt,1);
m = size(Xt,2);
if p==1
    cbar = -7;
    z = zeros(T,1);
elseif (p==2) | (p==3)
    cbar = -7;
    z = ones(T,1);
else
    cbar = -13.5;
    trend = 1:1:T;
    z = [ones(T,1) trend'];
end
rhobar = 1 + cbar/T;

ytlag = [0;yt(1:T-1,1)];
dXt = diffk(Xt,1);
ZH0 = [yt-ytlag,dXt];
ZH1 = [yt-rhobar*ytlag,dXt];

% penalty==0 for MAIC
% penalty==1 for BIC
% penalty==2 for AIC
% penalty==3 for MBIC
% penalty==4 for MAIC
if penalty==0
    [ytd, ssra] = glsd(yt,z,cbar);
    KOPT = s2ar(ytd,kmax,kmin); 
else
    KOPT = ejlags(ZH0,yt,Xt,p,T,penalty,kmax,kmin);
end

% Get test results
% [ ] = [LAMBDA,Critval,R2hat,kopt];
results = ejmain(ZH0(:,:),ZH1(:,:),p,rhobar,T,m,KOPT);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [kopt] = ejlags(ZH0,yt,Xt,p,T,penalty,kmax,kmin)
% 4 cases: BIC, AIC, MBIC, MAIC
ic = 999999*ones(kmax+1,1);
N = T-kmax-1;
for k=kmin:kmax
    %[Ahat, Shat] = varZH0(ZH0,p,k,kmax);
    [Ahat, Shat] = varZH0(ZH0(2:T,:),p,k,kmax);
    if penalty==1
        ic(k+1,1) = bic(Shat,N,k);
    elseif penalty==2
        ic(k+1,1) = aic(Shat,N,k);
    elseif penalty==3
        ic(k+1,1) = mbic(Shat,N,k,kmax,[yt,Xt],p);
    elseif penalty==4
        ic(k+1,1) = maic(Shat,N,k,kmax,[yt,Xt],p);
    end
end
[junk Iic] = min(ic,[],1);
kopt = [Iic-1];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [results] = ejmain(ZH0,ZH1,p,rhobar,T,m,kopt)
[sumAhat,SIGMAhat] = varZH0(ZH0,p,kopt,kopt);
% [sumAhat,SIGMAhat] = varZH0(ZH0(2:T,:),p,kopt,kopt);
OMEGAhat = inv(sumAhat)*SIGMAhat*inv(sumAhat');
R2hat = OMEGAhat(2:m+1,1)'*inv(OMEGAhat(2:m+1,2:m+1))*OMEGAhat(2:m+1,1)/OMEGAhat(1,1);
R2hat = real(R2hat);
invOMEGAhat = inv(OMEGAhat);
const = ones(T,1);
const_lag = [0;const(1:T-1,1)];
trend = [1:T]';
trend_lag = [0;trend(1:T-1,1)];
DH0 = [const-const_lag,const*ones(1,m),trend-trend_lag,trend*ones(1,m)];
DH1 = [const-rhobar*const_lag,const*ones(1,m),trend-rhobar*trend_lag,trend*ones(1,m)];
ZH0_GLS = ZH0*invOMEGAhat;
ZH1_GLS = ZH1*invOMEGAhat;
betatilde_H0 = betatilde(ZH0_GLS,DH0,invOMEGAhat,m,p);
betatilde_H1 = betatilde(ZH1_GLS,DH1,invOMEGAhat,m,p);
utildeH0 = ZH0 - (DH0.*(ones(T,1)*betatilde_H0'))*[eye(m+1);eye(m+1)];
utildeH1 = ZH1 - (DH1.*(ones(T,1)*betatilde_H1'))*[eye(m+1);eye(m+1)];
[junk,SIGMAtilde_H0] = varZH0(utildeH0,1,kopt,kopt);
[junk,SIGMAtilde_H1] = varZH0(utildeH1,1,kopt,kopt);
% Construct Statistic
LAMBDA = T * (trace(inv(SIGMAtilde_H0)*SIGMAtilde_H1) - m - rhobar);
% Get Critical Value
Critvals = [3.34,3.41,3.54,3.76,4.15,4.79,5.88,7.84,12.12,25.69; ...
            3.34,3.41,3.54,3.76,4.15,4.79,5.88,7.84,12.12,25.69; ...
            3.34,3.41,3.54,3.70,3.96,4.41,5.12,6.37,9.17,17.99; ...
            5.70,5.79,5.98,6.38,6.99,7.97,9.63,12.6,19.03,39.62; ...
            5.70,5.77,6.00,6.40,7.07,8.15,10.00,13.36,20.35,41.87];
if R2hat < 0.90
    R2index = 1 + floor(10*R2hat);
    R2weight = rem(10*R2hat,1);
    Critval = Critvals(p,R2index) + R2weight.*(Critvals(p,R2index+1) - Critvals(p,R2index));
elseif R2hat == 0.90
    Critval = Critvals(p,10);
else
    Critval = Critvals(p,10);
end
% Final Results
results = [LAMBDA,Critval,R2hat,kopt];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [beta] = betatilde(Z,D,invOMEGAhat,m,p)
denom = (D'*D).*(kron(ones(2,2),invOMEGAhat));
numer = sum(D.*[Z,Z],1)';
if p==1
    beta = zeros(2*(m+1),1);
elseif p==2
    beta = [inv(denom(1,1))*numer(1,1);zeros(2*m+1,1)];
elseif p==3
    beta = [inv(denom(1:m+1,1:m+1))*numer(1:m+1,1);zeros(m+1,1)];
elseif p==4
    beta = [inv(denom(1:m+2,1:m+2))*numer(1:m+2,1);zeros(m,1)];
elseif p==5
    beta = inv(denom)*numer;
end
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [sumCoeff,SIGMAhat] = varZH0(Z,p,kstar,kmax)
T = size(Z,1);
m = size(Z,2)-1;
if  p==1, 
    Zreg = []; 
elseif p==2, 
    Zreg = [ones(T,1)]; 
elseif p==3, 
    Zreg = [ones(T,1)]; 
elseif p==4, 
    Zreg = [ones(T,1),[1:T]']; 
else
    Zreg = [ones(T,1),[1:T]']; 
end
determ = size(Zreg,2);
if kstar > 0
    for i=1:kstar, Zreg = [Zreg lagn(Z,i)]; end    
end
Z = trimr(Z,kmax,0);
Zreg = trimr(Zreg,kmax,0);
if (p==1) & (kstar==0)
    ehat = Z;
    sumCoeff = eye(m+1);
else
    Zcoef = Zreg\Z;
    ehat = Z - Zreg*Zcoef;
    sumCoeff = eye(m+1) - Zcoef'*[zeros(determ,m+1);kron(ones(kstar,1),eye(m+1))];
end
SIGMAhat = ehat'*ehat./T;
% SIGMAhat = ehat'*ehat./(T-kmax);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = bic(sigma2,T,k)
n = size(sigma2,1);
x = log( det(sigma2) ) + ( log(T)*k*n*n )/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = aic(sigma2,T,k)
n = size(sigma2,1);
x = log( det(sigma2) ) + ( 2*k*n*n )/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = mbic(sigma2,T,k,kmax,y,p)
n = size(sigma2,1);
tau = cointLR(y,k,kmax,p);
x = log( det(sigma2) ) + log(T)*( tau + k*n*n )/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = maic(sigma2,T,k,kmax,y,p)
n = size(sigma2,1);
tau = cointLR(y,k,kmax,p);
x = log( det(sigma2) ) + ( tau + k*n*n )*2/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function results = cointLR(Y,k,kmax,p)
[T N] = size(Y);
dY = diffk(Y,1);
Ylag = lagn(Y,1);
X = [];
if k>0
    for i=1:k, X = [X lagn(dY,i)]; end,
end
const = ones(T,1);
trend = [1:T]';
if p==2
    Ylag = [Ylag const];
elseif  p==3
    X = [X const];
elseif p==4
    X = [X const];
    Ylag = [Ylag trend];
elseif p==5
    X = [X  const trend]; 
end
dY = trimr(dY,kmax+1,0);
Ylag = trimr(Ylag,kmax+1,0);
X = trimr(X,kmax+1,0);
if (k==0) & (p<3)
    R0 = dY;
    R1 = Ylag;
else
    R0 = dY - X*(X\dY);
    R1 = Ylag - X*(X\Ylag);
end
S11 = R1'*R1;
S00 = R0'*R0;
S01 = R0'*R1;
S10 = R1'*R0;
SS = S10*S00^(-1)*S01*S11^(-1);
as = sort(eig(SS));
tmp = -(T-kmax-1)*log(ones(length(as),1)-as);
results = sum(tmp);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kopt = s2ar(yts,kmax,kmin)
nt = size(yts,1);
tau = zeros(kmax+1,1);
s2e = 999999*ones(kmax+1,1);
dyts = diffk(yts,1);
reg = lagn(yts,1);
for i=1:kmax, reg = [reg lagn(dyts,i)]; end
dyts0 = dyts;
reg0 = reg;
dyts0 = trimr(dyts,kmax+1,0);
reg0 = trimr(reg,kmax+1,0);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-kmax-1;
for k=kmin:kmax
    b = reg0(:,1:k+1)\dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
end 
kk = 0:1:kmax;
ic(:,1) = log(s2e) + 2*(kk'+tau)./nef;
[junk Iic] = min(ic,[],1);
kopt = [Iic-1];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [yt, ssr] = glsd(y,z,cbar)
nt = size(y,1);
abar = 1 + cbar/nt;
ya = zeros(nt,1);
za = zeros(nt,size(z,2));
ya(1,1) = y(1,1);
za(1,:) = z(1,:);
ya(2:nt,1) = y(2:nt,1)-abar*y(1:nt-1,1);
za(2:nt,:) = z(2:nt,:)-abar*z(1:nt-1,:);
% Constructing the GLS detrended series
bhat = za\ya;                          
yt = y-z*bhat;
ssr = (ya-za*bhat)'*(ya-za*bhat);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = lagn(x,n)
ncol = size(x,2);
if n<0, y = [trimr(x,abs(n),0); zeros(abs(n),ncol)]; return, end 
y = [zeros(n,ncol); trimr(x,0,n)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = trimr(x,n1,n2)
n = size(x,1);
start = n1+1;   
finish = n-n2;
y = x(start:finish,:);
return;
