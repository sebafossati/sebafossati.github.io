% urtests.m
%
% Implements unit root tests discussed in Ng, S. and P. Perron (2001):
% "Lag Length Selection and The Construction of Unit Root Tests with Good
% Size and Power", Econometrica, 69, 6, 1519-1554.
%
% Inputs:   y -> univariate time series
%           p -> the order of the polynomial trend
%                a) p=0 for constant in z
%                b) p=1 for constant and linear trend in z
%           penalty -> 0 for MAIC, 1 for BIC
%           kmax -> maximum number of lags
%           kmin -> minimum number of lags
%
% Output:   Tests based on GLS detrended data for both the statistic and
%           the spectral density:
%           
%   za:  the Phillips-Perron test Z_alpha;
%   mza: the modified Phillip-Perron test MZ_alpha;
%   mzt: the modified Phillips-Perron MZ_t test;
%   msb: the modified Sargan-Bhargava test;
%   mpt: the modified point optimal test;
%   pt:  Elliott, Rothemberg and Stock feasible point optimal test;
%   adf: the augmented Dickey-Fuller test;
%   krule: the order of the autoregression selected by the data dependent
%   rule (used in constructing the spectral density estimator at
%   frequency zero);
%   a1: the sum of the autoregressive coefficients in the ADF
%   autoregression;
%   ahat: estimate of alpha.
%
% ---------------------------------------------------------
% Adapted after Ng and Perron's mic1 Gauss function
% ---------------------------------------------------------
%
% Written by:
% Sebastian Fossati
% Dept of Economics
% University of Washington

function [results] = urtests(y,p,penalty,kmax,kmin);

PRINT = 1;

nt = size(y,1);
if p==0
    z = ones(nt,1);
    cbar = -7;
else
    trend = 1:1:nt;
    z = [ones(nt,1) trend'];
    cbar = -13.5;
end

% Transform the data
[yt, ssra] = glsd(y,z,cbar);
ahat = yt(1:nt-1,1)\yt(2:nt,1);
r = yt(2:nt,1)-yt(1:nt-1,1)*ahat;
s2u = r'*r/(nt-1);
sumyt2 = yt(1:nt-1,1)'*yt(1:nt-1,1)/(nt-1)^2;
krule = s2ar(yt,penalty,kmax,kmin);
[adfgls, a1, sar] = adfk(yt,krule);

% Traditional ADF
[adf, junk] = adfols(y,z,krule);
adfcv = [-2.88,-3.43];

% Construct Statistics
bt = nt-1;
za = bt*(ahat-1)-(sar-s2u)/(2*sumyt2);
mza = ( (yt(nt,1)^2)/bt-sar )/(2*sumyt2);
msb = sqrt(sumyt2/sar);
mzt = mza*msb;

[ytf, ssr1] = glsd(y,z,0);
pt = ( ssra-(1+cbar/nt)*ssr1 )/sar;

if p==0
    mpt = (cbar*cbar*sumyt2-cbar*(yt(nt,1)*yt(nt,1))/nt)/sar;
else
    mpt = (cbar*cbar*sumyt2+(1-cbar)*(yt(nt,1)*yt(nt,1))/nt)/sar;
end

if p==0
    results.adf = [adf adfcv(1)];
    results.adfgls = [adfgls -1.98];
    results.pt = [pt 3.17];
    results.za = [za -8.35];
    results.mza = [mza -8.1];    
    results.mzt = [mzt -1.98];
    results.msb = [msb .233];
    results.mpt = [mpt 3.17];
    results.k = krule;
    results.a1 = a1;
    results.ahat = ahat;
else
    results.adf = [adf adfcv(2)];
    results.adfgls = [adfgls -2.91];
    results.pt = [pt 5.48];
    results.za = [za -17.3];
    results.mza = [mza -17.3];
    results.mzt = [mzt -2.91];
    results.msb = [msb .168];
    results.mpt = [mpt 5.48];
    results.k = krule;
    results.a1 = a1;
    results.ahat = ahat;
end

if PRINT==1
    disp(' ');
    disp('--------------------------------------------------');
    disp('      ADF Unit Root Test:                        ');
    disp('--------------------------------------------------');
    disp('     Test Statistic       5% C.V.    ');
    disp('--------------------------------------------------');
    fprintf('\t ADF: %-.4f\t \t %6.2f\n',results.adf(1),results.adf(2));
    disp('--------------------------------------------------');
    disp(' ');
    disp('--------------------------------------------------');
    disp('    Unit Root Tests with GLS detrended data:');
    disp('--------------------------------------------------');
    disp('     Test Statistic       5% C.V.    ');
    disp('--------------------------------------------------');
    fprintf('\t ADF: %-.4f\t \t %6.2f\n',results.adfgls(1),results.adfgls(2));
    fprintf('\t  Pt: %6.4f\t \t %6.2f\n',results.pt(1),results.pt(2));
    fprintf('\t  Za: %6.4f\t \t %6.2f\n',results.za(1),results.za(2));
    fprintf('\t MZa: %6.4f\t \t %6.2f\n',results.mza(1),results.mza(2));
    fprintf('\t MZt: %6.4f\t \t %6.2f\n',results.mzt(1),results.mzt(2));
    fprintf('\t MSB: %6.4f\t \t %6.2f\n',results.msb(1),results.msb(2));
    fprintf('\t MPT: %6.4f\t \t %6.2f\n',results.mpt(1),results.mpt(2));
    disp('--------------------------------------------------');
    fprintf('\t Estimated Coefficient: %6.4f\n',results.a1);
    disp(strcat('    Sample size (T):',int2str(nt)));
    disp(strcat('    Lag Order (k):',int2str(krule)));
    disp(strcat('    Case # for deterministic part (p):',int2str(p)));
    disp('--------------------------------------------------');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [adf, rho, s2vec] = adfk(yt,kstar)
reg = lagn(yt,1);
dyt = diffk(yt,1);
for i=1:kstar, reg = [reg lagn(dyt,i)]; end
dyt = trimr(dyt,kstar+1,0);
reg = trimr(reg,kstar+1,0);
b = reg\dyt;
ee = dyt-reg*b;
nef = size(dyt,1);
s2e = ee'*ee/nef;
xx = inv(reg'*reg);
sre = xx(1,1)*s2e;
adf = b(1)/sqrt(sre);
rho = b(1)+1;
sumb = 0;
if kstar>0, sumb = sum(b(2:kstar+1)); end
s2vec = s2e/(1-sumb)^2;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [adf, rho] = adfols(yt,z,kstar)
reg = [lagn(yt,1),z];
dyt = diffk(yt,1);
for i=1:kstar, reg = [reg lagn(dyt,i)]; end
dyt = trimr(dyt,kstar+1,0);
reg = trimr(reg,kstar+1,0);
b = reg\dyt;
ee = dyt-reg*b;
nef = size(dyt,1)-kstar-1-size(z,2);
s2e = ee'*ee/nef;
xx = inv(reg'*reg);
sre = xx(1,1)*s2e;
adf = b(1)/sqrt(sre);
rho = b(1)+1;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kopt = s2ar(yts,penalty,kmax,kmin)
nt = size(yts,1);
tau = zeros(kmax+1,1);
s2e = 999999*ones(kmax+1,1);
dyts = diffk(yts,1);
reg = lagn(yts,1);
for i=1:kmax, reg = [reg lagn(dyts,i)]; end
dyts0 = dyts;
reg0 = reg;
dyts0 = trimr(dyts,kmax+1,0);
reg0 = trimr(reg,kmax+1,0);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-kmax-1;
for k=kmin:kmax
    b = reg0(:,1:k+1)\dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
end 
kk = 0:1:kmax;
if penalty==0
    mic = log(s2e)+2*(kk'+tau)./nef;
else
    mic = log(s2e)+log(nef)*(kk')./nef;
end 
[mmic I] = min(mic);
kopt = I-1;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [yt, ssr] = glsd(y,z,cbar)
nt = size(y,1);
abar = 1 + cbar/nt;
ya = zeros(nt,1);
za = zeros(nt,size(z,2));
ya(1,1) = y(1,1);
za(1,:) = z(1,:);
ya(2:nt,1) = y(2:nt,1)-abar*y(1:nt-1,1);
za(2:nt,:) = z(2:nt,:)-abar*z(1:nt-1,:);
% Constructing the GLS detrended series
bhat = za\ya;                          
yt = y-z*bhat;
ssr = (ya-za*bhat)'*(ya-za*bhat);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = lagn(x,n)
ncol = size(x,2);
if n<0, y = [trimr(x,abs(n),0); zeros(abs(n),ncol)]; return, end 
y = [zeros(n,ncol); trimr(x,0,n)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = trimr(x,n1,n2)
n = size(x,1);
start = n1+1;   
finish = n-n2;
y = x(start:finish,:);
return;
