% Inflation tests
%
% To generate results reported on table 7 run:
% [data,univ,covar]=inflation_tests([1,1]);
% [data,univ,covar]=inflation_tests([4,0]);


function [data,univ,covar] = inflation_tests(penalty)

% Set defaults
warning off all;
format short g
set(0,'DefaultFigureColor','w');
set(0,'DefaultTextColor','k');
set(0,'DefaultAxesXColor','k');
set(0,'DefaultAxesYColor','k');

% date1 date2 date3 CPI unrate tb3m GDP
[DATA, headertext] = xlsread('data_app_2.xls','quarterly');
dates = [1947.00:.25:2010.5]';

% Get inflation rates
inf = 400*diffk(log(DATA(:,4)),1);

% Get covariates
u = DATA(:,5);
y = 400*log(DATA(:,7));
i = DATA(:,6);

data = [inf,u,y,i];

% Get differenced data for graphs
dinf = diffk(inf,1);
du = diffk(u,1);
dy = diffk(y,1);
di = diffk(i,1);

% Set test
first = 49; % Start date 1959.1
last = size(DATA,1);

% Univariate unit root tests
kmax = floor(12*((last-first)/100)^.25);
univ.inf = urtests(inf(first:last),0,0,kmax,0);
univ.u = urtests(u(first:last),0,0,kmax,0);
univ.y = urtests(y(first:last),1,0,kmax,0);
univ.i = urtests(i(first:last),0,0,kmax,0);

% Unit root in inflation?
setcase = 3;
test2 = test(inf,u,first,last,setcase,penalty);
test3 = test(inf,y,first,last,setcase,penalty);
test4 = test(inf,i,first,last,setcase,penalty);
% Results Table
results.inf = [test2 test3 test4];


covar = results;

% Get figures
do_graphs = 1;
do_export = 0;

if do_graphs==1
% Figure 1
figure;
set(gcf, ...
    'PaperUnits','inches', ...
    'PaperSize',[7 7], ...
    'PaperPosition',[0 0 7 7], ...
    'PaperPositionMode','manual');
set(gcf, ...
    'defaultaxesfontsize',6, ...
    'defaultaxeslinewidth',0.7, ...
    'defaultlinelinewidth',0.9, ...
    'defaultpatchlinewidth',0.7);
% 1
subplot(4,2,1)
fl = -2; tp = 15; 
% add nber dates
add_nber(fl,tp,1)
hold on
line = zeros(length(dates),1);
plot(dates+4,line,'k','LineWidth',.7)
hold on
plot(dates(first:last),inf(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('\pi','FontSize',10)
% 2
subplot(4,2,2)
fl = -5; tp = 5; 
% add nber dates
add_nber(fl,tp,1)
hold on
line = zeros(length(dates),1);
plot(dates+4,line,'k','LineWidth',.7)
hold on
plot(dates(first:last),dinf(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('\Delta{\pi}','FontSize',10)
%3
subplot(4,2,3)
fl = 0; tp = 12; 
% add nber dates
add_nber(fl,tp,1)
hold on
plot(dates(first:last),u(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('u','FontSize',10)
% 4
subplot(4,2,4)
fl = -2; tp = 2; 
% add nber dates
add_nber(fl,tp,1)
hold on
line = zeros(length(dates),1);
plot(dates+4,line,'k','LineWidth',.7)
hold on
plot(dates(first:last),du(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('\Delta{u}','FontSize',10)
% 5
subplot(4,2,5)
fl = 7*400; tp = 10*400; 
% add nber dates
add_nber(fl,tp,1)
hold on
plot(dates(first:last),y(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('y','FontSize',10)
% 6
subplot(4,2,6)
fl = -16; tp = 16; 
% add nber dates
add_nber(fl,tp,1)
hold on
line = zeros(length(dates),1);
plot(dates+4,line,'k','LineWidth',.7)
hold on
plot(dates(first:last),dy(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('\Delta{y}','FontSize',10)
% 7
subplot(4,2,7)
fl = 0; tp = 16; 
% add nber dates
add_nber(fl,tp,1)
hold on
plot(dates(first:last),i(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('i','FontSize',10)
% 8
subplot(4,2,8)
fl = -5; tp = 5; 
% add nber dates
add_nber(fl,tp,1)
hold on
line = zeros(length(dates),1);
plot(dates+4,line,'k','LineWidth',.7)
hold on
plot(dates(first:last),di(first:last),'k-','LineWidth',.8)
hold off
axis([DATA(first,2)-.5 DATA(last,2)+1 fl tp]);
title('\Delta{i}','FontSize',10)
if do_export==1, 
    print(gcf,'-deps','application_updated.eps')
end
    
end

function [result] = test(y,x,first,last,setcase,penalty)
y = y(first:last);
x = x(first:last,:);
kmax = floor(12*((last-first)/100)^.25);
result = NaN(6,1,2);
result(1:4,1,1) = ej_test(y,x,setcase,penalty(1),kmax,0)';
result(1:6,1,2) = cadfgls_test(y,x,setcase,penalty(2),kmax,0)';
% result(1:4,1,1) = ej_test(y,x,setcase,penalty(1),3,3)';
% result(1:6,1,2) = cadfgls_test(y,x,setcase,penalty(2),3,3)';
return;

function [] = add_nber(fl,tp,freq)
% Adds shaded area to cycle graps

% NBER dates in decimals
% 0 for monthly, 1 for quarterly
if(freq==0);
    recession = [1948+10/12 19490+9/12 ;
                1953+06/12 1954+04/12 ;
                1957+07/12 1958+03/12 ;
                1960+02/12 1961+01/12 ;
                1969+11/12 1970+10/12 ;
                1973+10/12 1975+02/12 ;
                1980+00/12 1980+06/12 ;
                1981+06/12 1982+10/12 ;
                1990+06/12 1991+02/12 ;
                2001+02/12 2001+10/12 ;
                2007+11/12 2009+05/12 ] ;
elseif(freq==1); 
    recession = [1948.75 1949.75 ;
                 1953.25 1954.25 ;
                 1957.50 1958.25 ;
                 1960.25 1961.00 ;
                 1969.75 1970.75 ;
                 1973.75 1975.00 ;
                 1980.00 1980.50 ;
                 1981.50 1982.75 ;
                 1990.50 1991.00 ;
                 2001.00 2001.75 ;
                 2007.75 2009.25 ] ;
end;

% y is the size of the y-axis
marg = (tp-fl)*.01;
y = [tp-marg; fl+marg; fl+marg; tp-marg];
x = [recession(:,1), recession(:,1), recession(:,2), recession(:,2),];
col = 0.8541;
fill(x,y,[col col col],'Linestyle','none');
return;

function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;
