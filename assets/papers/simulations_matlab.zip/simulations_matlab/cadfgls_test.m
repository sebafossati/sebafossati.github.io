% cadfgls.m
%
% Implements unit root tests discussed in:
%
% Pesavento, E. (2006): "Near-Optimal Unit Root Tests with Stationary
% Covariates with Better Finite Sample Size", working paper.
%
% Fossati, S. (2011): "Covariate Unit Root Tests with Good Size and Power",
% Computational Statistics and Data Analysis, forthcoming.
%
% Inputs:   
%           yt      - a Tx1 vector of potentially stationary variables
%           Xt      - a Txm matrix of I(1) covariates
%           p       - the case number indexing the deterministic component
%           penalty - 0 for MAIC/MAIC, 1 for BIC, 2 for AIC, 3 for MBIC, 
%                     4 for MAIC 
%           kmax    - maximum number of leads/lags terms
%           kmin    - minimum number of leads/lags terms
%
% Output:
%           tstat   - the point optimal unit root test using covariates
%           critval - the 5% critical value
%           R2      - the estimated R^2
%           kopt    - selected number of lags
%           
% Written by:
% Sebastian Fossati
% Dept of Economics
% University of Alberta

function [results] = cadfgls_test(yt,Xt,p,penalty,kmax,kmin)
% yt and Xt (series in levels) are of size T
% Xt is I(1)
% results = [LAMBDA,Critval,R2hat,kopt]

T = size(yt,1);
m = size(Xt,2);
if p==1
    cbar = -7;
    z = zeros(T,1);
elseif (p==2) | (p==3)
    cbar = -7;
    z = ones(T,1);
else
    cbar = -13.5;
    trend = 1:1:T;
    z = [ones(T,1) trend'];
end

% Step 1
% Transform the data
[yt, ssra] = glsd(yt,z,cbar);
% Step 2
% Transform the data
dXt = diffk(Xt,1);
[dXt] = olsd(dXt,p);

% Get optimal number of lags
% penalty==0 for MAIC/MAIC
% penalty==1 for BIC
% penalty==2 for AIC
% penalty==3 for MBIC
% penalty==4 for MAIC
krule = s2ar(yt,kmax,kmin);
if penalty==0
    tmp = optlags(yt,dXt,krule(1,4),kmin); % send k(maic) and get [k1,k2,k3]
    KOPT = tmp(4,:);
else
    KOPT = [krule(1,penalty),krule(1,penalty),krule(1,penalty)];
end

% Get test results
% results = [tstat,critval,R2,kopt];
results = cadfglsmain(yt,dXt,p,KOPT);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [results] = cadfglsmain(yt,dXt,p,kopt)
nt = size(yt,1);
m = size(dXt,2);
k1 = kopt(1);
k2 = kopt(2);
k3 = kopt(3);
% Generate regressors
dyt = diffk(yt,1);
reg = lagn(yt,1);
for i=1:k1, reg = [reg lagn(dyt,i)]; end
reg = [reg dXt];
for i=1:k2, reg = [reg lagn(dXt,i)]; end
for i=1:k3, reg = [reg lagn(dXt,-i)]; end
% Trim sample
dyt = trimr(dyt,max(k1,k2)+1,k3);
reg = trimr(reg,max(k1,k2)+1,k3);
% Run regression
invREG2 = inv(reg'*reg);
bhat = invREG2*reg'*dyt;
ehat = dyt - reg*bhat;
% Effective number of observation adjusted for degrees of freedom
N = size(dyt,1)-1-k1-(1+k2+k3)*m;
% N = size(dyt,1)-1-k1-(1+k2+k3)*m;
sigma2=(ehat'*ehat)/N;
Covar = invREG2*sigma2;
se = sqrt(diag(Covar));
tstat = bhat(1)/se(1);
vhat = ehat + reg(:,2+k1:length(reg(1,:)))*bhat(2+k1:length(reg(1,:)));
[omega,bandw] = lr_var([vhat,ehat]);
R2=1-(omega(2,1)^2)/(omega(1,1)*omega(2,2));
% Get Critical Value
Critvals = [-1.948,-1.939,-1.929,-1.918,-1.905,-1.881,-1.864,-1.839,-1.818,-1.773; ...
            -1.948,-1.939,-1.929,-1.918,-1.905,-1.881,-1.864,-1.839,-1.818,-1.773; ...
            -1.948,-1.909,-1.866,-1.812,-1.760,-1.707,-1.647,-1.579,-1.497,-1.405; ...
            -2.836,-2.786,-2.738,-2.688,-2.628,-2.568,-2.498,-2.418,-2.343,-2.315; ...
            -2.835,-2.780,-2.730,-2.664,-2.586,-2.497,-2.401,-2.286,-2.1520,-2.017];
if R2 < 0.90
    R2index = 1 + floor(10*R2);
    R2weight = rem(10*R2,1);
    critval = Critvals(p,R2index) + R2weight.*(Critvals(p,R2index+1) - Critvals(p,R2index));
elseif R2 == 0.90
    critval = Critvals(p,10);
else
    critval = Critvals(p,10);
end
results = [tstat,critval,R2,kopt];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [kopt] = optlags(yt,dXt,kmax,kmin)
% 
nt = size(yt,1);
m = size(dXt,2);
tau = zeros((kmax+1)^3,1);
s2e = 999999*ones((kmax+1)^3,1);
dyt = diffk(yt,1);

reg = lagn(yt,1);
for i=1:kmax, reg = [reg lagn(dyt,i)]; end
reg = [reg dXt];
for i=1:kmax, reg = [reg lagn(dXt,i)]; end
for i=1:kmax, reg = [reg lagn(dXt,-i)]; end

% Trim sample
dyt0 = trimr(dyt,kmax+1,kmax);
reg0 = trimr(reg,kmax+1,kmax);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-2*kmax-1;

regy = reg0(:,1:1+kmax);
regx = reg0(:,1+kmax+1:1+kmax+m);
regxlag = reg0(:,1+kmax+m+1:1+kmax+m+kmax*m);
regxlead = reg0(:,1+kmax+m+kmax*m+1:1+kmax+m+2*kmax*m);

ks = zeros((kmax+1)^3,3);
ii = kmin+1;
for k1=kmin:kmax
    for k2=kmin:kmax
        for k3=kmin:kmax
            ks(ii,:) = [k1,k2,k3];
            reg1 = [regy(:,1:1+k1),regx,regxlag(:,1:k2*m),regxlead(:,1:k3*m)];
            b = reg1\dyt0;
            e = dyt0-reg1*b;
            s2e(ii) = e'*e/nef;
            tau(ii) = (b(1)*b(1))*sumy/s2e(ii);
            ii = ii+1;
        end
    end
end

kk = 1+ks(:,1)+(1+ks(:,2)+ks(:,3))*m;
ic(:,1) = log(s2e) + log(nef)*(kk)./nef;
ic(:,2) = log(s2e) + 2*(kk)./nef;
ic(:,3) = log(s2e) + log(nef)*(kk+tau)./nef;
ic(:,4) = log(s2e) + 2*(kk+tau)./nef;
[junk Iic] = min(ic,[],1);
kopt = ks(Iic,:);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Non-parametric estimation of the long-run variance.
% Adapted from Bruce Hansen's Gauss function urreg.pcr.
function [omega,bandw] = lr_var(e)
kernel  = 1;
band    = 0;
[T,p] = size(e);
% Determine bandwidth following Andrews (1991)
if band==0
    elag = e(1:T-1,:);
    et = e(2:T,:);
    % Estimate AR(1) models for each column
    ae = sum(elag.*et)'./sum(elag.^2)';
    ee = et-elag.*(ones(T-1,1)*ae');
    se = mean(ee.^2)';
    % Intermediate calculations
    ad = sum((se./((1-ae).^2)).^2)';
    aese = ae.*se;
    a1 = 4*sum((aese./((((1-ae).^3).*(1+ae))*ones(1,length(aese(1,:))))).^2)'/ad;
    a2 = 4*sum((aese./(((1-ae).^4)*ones(1,length(aese(1,:))))).^2)'/ad;
    if kernel==2
        bandw = 1.3221*((a2*T)^.2);     % Quadratic Spectral
    elseif kernel==1
        bandw = 2.6614*((a2*T)^.2);     % Parzen
        if bandw>(T-2), bandw = T-2; end
    elseif kernel==3;                   % Bartlett
        bandw = 1.1447*((a1*T)^.333);
        if bandw>(T-2), bandw = T-2; end
    end
else
    bandw = band;
end
% Get weights      
if kernel==2            % Quadratic Spectral Kernel
    N = T-1;
    di = ((1:N)./bandw)';
    mi = 1.2*pi*di;
    kern = 25*( (sin(mi)./mi - cos(mi) )./( (di.^2).*12*pi^2 ));
elseif kernel==1        % Parzen kernel
    N = T-1;
    bT = floor(bandw);
    if  bT<=0
        kern = zeros(N,1);
    else
        ai = ((1:N)./bandw)';
        kern = (1-6*(ai.^2)+6*(ai.^3)).*(ai<=.5);
        kern = kern + (2*(1-ai).^3).*(ai>.5);
        kern = kern.*(ai<=1);
    end;
elseif kernel==3        % Bartlett kernel
    N = T-1;
    bT = floor(bandw);
    if bT<=0
        kern = zeros(N,1);
    else
        ai = ((1:N)./bandw)';
        kern = (1-ai).*(ai<=1);
    end
end
% Estimate Covariances
tmp = zeros(p,p);
for i=1:N
    kj = kern(i);
    tmp = tmp + (e(1:T-i,:)'*e(1+i:T,:))*kj;
end
omega = (e'*e + tmp + tmp')/T;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kopt = s2ar(yts,kmax,kmin)
nt = size(yts,1);
tau = zeros(kmax+1,1);
s2e = 999999*ones(kmax+1,1);
dyts = diffk(yts,1);
reg = lagn(yts,1);
for i=1:kmax, reg = [reg lagn(dyts,i)]; end
dyts0 = dyts;
reg0 = reg;
dyts0 = trimr(dyts,kmax+1,0);
reg0 = trimr(reg,kmax+1,0);
sumy = reg0(:,1)'*reg0(:,1);
nef = nt-kmax-1;
for k=kmin:kmax
    b = reg0(:,1:k+1)\dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
end 
kk = 0:1:kmax;
ic(:,1) = log(s2e)+log(nef)*(kk')./nef;
ic(:,2) = log(s2e)+2*(kk')./nef;
ic(:,3) = log(s2e) + log(nef)*(kk'+tau)./nef;
ic(:,4) = log(s2e) + 2*(kk'+tau)./nef;
[junk Iic] = min(ic,[],1);
kopt = [Iic-1];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [yd, ssr] = glsd(y,z,cbar)
nt = size(y,1);
abar = 1 + cbar/nt;
ya = zeros(nt,1);
za = zeros(nt,size(z,2));
ya(1,1) = y(1,1);
za(1,:) = z(1,:);
ya(2:nt,1) = y(2:nt,1)-abar*y(1:nt-1,1);
za(2:nt,:) = z(2:nt,:)-abar*z(1:nt-1,:);
% Constructing the GLS detrended series
bhat = za\ya;                          
yd = y-z*bhat;
ssr = (ya-za*bhat)'*(ya-za*bhat);
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Xd] = olsd(X,p)
T = size(X,1);
if p<3
    Xd = X; return,
elseif (p==3) | (p==4)
    z = ones(T,1);
else
    trend = 1:1:T;
    z = [ones(T,1) trend'];
end
bhat = z\X;                          
Xd = X - z*bhat;
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = lagn(x,n)
ncol = size(x,2);
if n<0, y = [trimr(x,abs(n),0); zeros(abs(n),ncol)]; return, end 
y = [zeros(n,ncol); trimr(x,0,n)];
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = trimr(x,n1,n2)
n = size(x,1);
start = n1+1;   
finish = n-n2;
y = x(start:finish,:);
return;
