% Dating US Business Cycles with Macro Factors
% out-of-sample results - pc factor
% 
% Sebastian Fossati
% 09/2015


% set up
clear all
warning off all; 
format short g

% set seed
randn('seed',123);


% get factors
load pc_factors;


% NBER recession dates

% construct recessions data
NBERt = [kron((1960:2010)',ones(12,1)),kron(ones(2010-1960+1,1),(1:12)')];
nt = size(NBERt,1);
NBERt = [NBERt,zeros(nt,1)];
dates = [1960.00:1/12:2010.9167]';

% recessions dates
recessions = [((1960-1960)*12+4:(1961-1960)*12+2)';
              ((1969-1960)*12+12:(1970-1960)*12+11)';
              ((1973-1960)*12+11:(1975-1960)*12+3)';
              ((1980-1960)*12+1:(1980-1960)*12+7)';
              ((1981-1960)*12+7:(1982-1960)*12+11)';
              ((1990-1960)*12+7:(1991-1960)*12+3)';
              ((2001-1960)*12+3:(2001-1960)*12+11)';
              ((2007-1960)*12+12:(2009-1960)*12+6)' ]; 
months = size(recessions,1);
for i=1:months, NBERt(recessions(i),3) = 1; end;

% get peaks and troughs
peaks = [];
troughs = [];
temp = [0;NBERt(2:end,3)-NBERt(1:end-1,3)];
for i=1:nt-1
    if(temp(i,1)==1), peaks = [peaks;dates(i,1)];end;
    if(temp(i,1)==-1), troughs = [troughs;dates(i-1,1)];end;
end


% out-of-sample results

% end number of observations without the sign condition
rsc = 12;

% Number of draws in MCMC algorithm
iNumDraws = 5000;
% Number of burn-in draws
iNumBurn = 1000;

% first nowcast
nstart = 229; % 1979.01
nobs = rows(dates);

% allocate storage
ystar_all = NaN(nobs,nobs-nstart+1,3);
prhat_all = NaN(nobs,nobs-nstart+1,3);

for tn = nstart:nobs; 
    
    % remove nber dates for the last 12 observations
    yt = NBERt(1:tn,3);
    yt((tn-rsc):tn,1) = ones(rsc+1,1)*yt(tn-rsc,1);

    % get effective sample 1960.3 - tn
    n = tn-2; % effective number of observations
    y0t = yt(3:tn,1);
    f0t = f1hat(3:tn,tn-nstart+1);
    x0t = [ones(n,1),f0t]; 
    
    % estimate probit model
    [results] = get_probit_out(y0t,x0t,rsc,iNumDraws,iNumBurn,0);
    % store results
    ystar_all(3:tn,tn-nstart+1,1) = results.ysmean;
    prhat_all(3:tn,tn-nstart+1,1) = results.phat;
    
    % estimate probit-ar model
    [results] = get_probit_out(y0t,x0t,rsc,iNumDraws,iNumBurn,1);
    % store results
    ystar_all(3:tn,tn-nstart+1,2) = results.ysmean;
    prhat_all(3:tn,tn-nstart+1,2) = results.phat;
    
    % estimate ms model
    [results] = get_msm_out(f0t);
    % store results
    prhat_all(3:tn,tn-nstart+1,3) = results.phat;
    
    disp(tn)
end

results_pc.ystar = ystar_all;
results_pc.prhat = prhat_all;


% Save workspace
file = 'out_modelpc.mat';
save(file)
