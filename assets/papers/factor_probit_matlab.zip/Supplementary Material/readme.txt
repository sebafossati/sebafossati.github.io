
Description of replication files for
Dating US Business Cycles with Macro Factors
December 28, 2015
Sebastian Fossati

============================================================================

Estimation of Macro Factors

Data:  
Data for the series used for the dynamic factor model are in coinc.mat.
Data for the series used for the static (PC) factor model are in panel.mat.
Real-time data are in real_time_data.mat.

Code:
The program get_dy_factors.m uses the data set coinc.mat to recursively 
estimate the dynamic factor using ex-post revised data. 
The program get_pc_factors.m uses the data set panel.mat to recursively 
estimate the static factors using ex-post revised data. 
The program get_rt_factors.m uses the data set real_time_data.mat to 
recursively estimate the dynamic factor using real-time data. 

Estimated factors are stored as df_factors.mat, pc_factors.mat,
rt_factors.mat.

============================================================================

Probabilities of Recession

Code:
The program results00.m computes some preliminary in-sample results.
The programs results01_df.m and results01_pc.m compute out-of-sample
probabilities of recessions using ex-post revised data.
The programs results01_df_rt.m and results01_pc_rt.m compute out-of-sample
probabilities of recessions using real-time data.

Note: Each of these programs will take several days to run. 

Tables: 
1 is computed in results00.m; 2, 3, and 4 are computed in results02.m;
5 is computed in results02_rt.m.

Figures:
All figures are produced in figures01.m.

============================================================================
