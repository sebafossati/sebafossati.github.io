% Dating US Business Cycles with Macro Factors
% out-of-sample tables
% 
% Sebastian Fossati
% 10/2015


% load results
clear all
load out_modeldf.mat
load out_modelpc.mat


%% 

% get variables
months = trimr(dates,nstart-1,0);
pr_df = [   diag(trimr(results_df.prhat(:,:,1),nstart-1,0)),...
            diag(trimr(results_df.prhat(:,:,2),nstart-1,0)),...
            diag(trimr(results_df.prhat(:,:,3),nstart-1,0))];
pr_pc = [   diag(trimr(results_pc.prhat(:,:,1),nstart-1,0)),...
            diag(trimr(results_pc.prhat(:,:,2),nstart-1,0)),...
            diag(trimr(results_pc.prhat(:,:,3),nstart-1,0))];
prob = [NBERt(nstart:nobs,3),pr_df,pr_pc];

% Recession and expansion months
rec = (prob(:,1)==1);
exp = (prob(:,1)==0);
nobs2 = [size(prob(:,1),1);sum(rec);sum(exp)];

% QPS & LPS
QPS = zeros(3,6);
LPS = zeros(3,6);
for i=1:6, 
    tmp = get_score(prob(:,1),prob(:,i+1)); 
    QPS(1,i) = tmp(1,1);
    LPS(1,i) = tmp(2,1);
    tmp = get_score(prob(rec,1),prob(rec,i+1)); 
    QPS(2,i) = tmp(1,1);
    LPS(2,i) = tmp(2,1);
    tmp = get_score(prob(exp,1),prob(exp,i+1)); 
    QPS(3,i) = tmp(1,1);
    LPS(3,i) = tmp(2,1);
end;

% out-of-sample table
table_out_1 = [QPS;LPS];


%% 

% missclassification loss

% cut off = .5
cut_off = .5;
class50 = [prob(:,1),(prob(:,2:7)>cut_off)];

L50 = zeros(3,6);
for i=1:6, 
    L50(1,i) = misloss(prob(:,1),prob(:,i+1),cut_off,.5); 
    L50(2,i) = misloss(prob(rec,1),prob(rec,i+1),cut_off,.5);
    L50(3,i) = misloss(prob(exp,1),prob(exp,i+1),cut_off,.5);
end;


% cut off = sample proportion
pbar = sum(prob(:,1))/size(prob(:,1),1);
cut_off = pbar;
classPB = [prob(:,1),(prob(:,2:7)>cut_off)];

LPB = zeros(3,6);
for i=1:6, 
    LPB(1,i) = misloss(prob(:,1),prob(:,i+1),cut_off,.5); 
    LPB(2,i) = misloss(prob(rec,1),prob(rec,i+1),cut_off,.5);
    LPB(3,i) = misloss(prob(exp,1),prob(exp,i+1),cut_off,.5);
end;

% out-of-sample table
table_out_2 = [L50;LPB];


%%

% optimal cut off
% find optimal cutt of values
step = 0.01;
coval = zeros((1+1/step),7);
for i=1:(1+1/step)
    cut_off = (i-1)*step;
    coval(i,1) = cut_off;
    for j=1:6
        coval(i,j+1) = misloss(prob(:,1),prob(:,j+1),cut_off,.5); 
    end;
end;
[junk,I] = min(coval);
opcut_off = coval(I(2:7),1);

LOP = zeros(3,6);
classOP = prob(:,1);
for i=1:6, 
    classOP = [classOP,(prob(:,i+1)>opcut_off(i))];
    LOP(1,i) = misloss(prob(:,1),prob(:,i+1),opcut_off(i),.5); 
    LOP(2,i) = misloss(prob(rec,1),prob(rec,i+1),opcut_off(i),.5);
    LOP(3,i) = misloss(prob(exp,1),prob(exp,i+1),opcut_off(i),.5);
end;


% out-of-sample table
table_out_3 = [opcut_off';LOP];


%%

% loss as a function of q
cut_off = .5;
step = 0.01;
ml50_q = NaN((1+1/step),7);
for i=11:(1+1/step-10)
    q = (i-1)*step;
    ml50_q(i,1) = q;
    for j=1:6
        ml50_q(i,j+1) = misloss(prob(:,1),prob(:,j+1),cut_off,q); 
    end
end

% loss as a function of q
cut_off = pbar;
step = 0.01;
mlPB_q = NaN((1+1/step),7);
for i=11:(1+1/step-10)
    q = (i-1)*step;
    mlPB_q(i,1) = q;
    for j=1:6
        mlPB_q(i,j+1) = misloss(prob(:,1),prob(:,j+1),cut_off,q); 
    end
end


%%

% save results
disp('Dating U.S. Business Cycles with Macro Factors');
disp('Table: Out-of-sample fit');
disp('   ');
fprintf('Cut-off values: 0.50, %.2f, and optimal.\n',pbar);
fprintf('Optimal cut-off values: %.2f, %.2f, %.2f, %.2f, %.2f, %.2f.\n',opcut_off);
disp('   ');
disp(table_out_1); 
disp(table_out_2); 
disp(table_out_3); 
disp('   ');

latex(table_out_1,'nomath','%.2f');
latex(table_out_2,'nomath','%.2f');
latex(table_out_3,'nomath','%.2f');


% % Save workspace
% file = 'results02.mat';
% save(file)
