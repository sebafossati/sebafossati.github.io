% Dating US Business Cycles with Macro Factors
% figures
% 
% Sebastian Fossati
% 10/2015


clear all

set(0,'DefaultFigureColor','w');
set(0,'DefaultTextColor','k');
set(0,'DefaultAxesXColor','k');
set(0,'DefaultAxesYColor','k');

% export figures?
do_export = 1;


%%
% in-sample

% load results
load results00

% dynamic factor
fl = -8; tp = 4;
figure;set(gcf,'PaperPosition',[0 0 7 2.5], ...
        'defaultaxesfontsize',8, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
% add nber dates
yy = [tp;fl;fl;tp];
xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
col = 0.8541;
fill(xx,yy,[col col col],'Linestyle','none');
hold on
plot([dates(1,1)-1 dates(nobs,1)+1],[0,0],'k-','LineWidth',.7)
hold on
plot(dates,macro(:,16),'LineWidth',1.2,'Color',[.5 .5 .5])
hold on
plot(dates,x0t,'LineWidth',1.2,'Color',[0 0 .5])
hold off
axis([1959 2012 fl tp])
xlabel('    ','FontSize',1)
text(dates(179,1),x0t(179,1),'\leftarrowDynamic Factor',...
    'HorizontalAlignment','left','FontSize',8)
box on
set(gca,'Layer','top');
if do_export==1,
    print('-depsc2','fig1.eps')
end

% probabilitites
figure;set(gcf,'PaperPosition',[0 0 7 2.5], ...
        'defaultaxesfontsize',8, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
% add nber dates
yy = [1;0;0;1];
xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
col = 0.8541;
fill(xx,yy,[col col col],'Linestyle','none');
hold on
plot(dates,prhat_df,'LineWidth',1.2,'Color',[0 0 .5])
hold off
axis([1959 2012 0 1]);
xlabel('    ','FontSize',1)
box on
set(gca,'Layer','top');
if do_export==1, 
    print(gcf,'-depsc','fig2.eps')
end


% pc factor
fl = -6; tp = 3;
figure;set(gcf,'PaperPosition',[0 0 7 2.5], ...
        'defaultaxesfontsize',8, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
% add nber dates
yy = [tp;fl;fl;tp];
xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
col = 0.8541;
fill(xx,yy,[col col col],'Linestyle','none');
hold on
plot([dates(1,1)-1 dates(nobs,1)+1],[0,0],'k-','LineWidth',.7)
hold on
plot(dates,macro(:,16),'LineWidth',1.2,'Color',[.5 .5 .5])
hold on
plot(dates,x1t(:,1),'LineWidth',1.2,'Color',[0 0 .5])
hold off
axis([1959 2012 fl tp])
xlabel('    ','FontSize',1)
text(dates(179,1),x1t(179,1),'\leftarrowFirst PC Factor',...
    'HorizontalAlignment','left','FontSize',8)
box on
set(gca,'Layer','top');
if do_export==1,
    print('-depsc2','fig3.eps')
end

% probabilitites
figure;set(gcf,'PaperPosition',[0 0 7 2.5], ...
        'defaultaxesfontsize',8, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
% add nber dates
yy = [1;0;0;1];
xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
col = 0.8541;
fill(xx,yy,[col col col],'Linestyle','none');
hold on
plot(dates,prhat_pc,'LineWidth',1.2,'Color',[0 0 .5])
hold off
axis([1959 2012 0 1]);
xlabel('    ','FontSize',1)
box on
set(gca,'Layer','top');
if do_export==1, 
    print(gcf,'-depsc','fig4.eps')
end


%%

load results02

% end-of-sample results
figure;set(gcf,'PaperPosition',[0 0 7 5], ...
        'defaultaxesfontsize',7, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
tmp = [1,3,5,2,4,6];
for i=1:6
    subplot(3,2,tmp(i))
    % add nber dates
    yy = [1;0;0;1];
    xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
    col = 0.8541;
    fill(xx,yy,[col col col],'Linestyle','none');
    hold on
    plot(months,prob(:,i+1),'LineWidth',1.2,'Color',[0 0 .5])
    hold on
    plot([dates(1,1)-2 dates(end,1)+2],[0.5,0.5],'k--','LineWidth',.7)
    hold on
    plot([dates(1,1)-2 dates(end,1)+2],[pbar,pbar],'k--','LineWidth',.7)
    hold on
    plot([dates(1,1)-2 dates(end,1)+2],[opcut_off(i),opcut_off(i)],'k-','LineWidth',.7)
    hold off
    axis([1978 2012 0 1])
    if i==1, text(1983,.92,'(1) DF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==2, text(1983,.92,'(2) DF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==3, text(1983,.92,'(3) DF-MS','HorizontalAlignment','left','FontSize',8); end;
    if i==4, text(1983,.92,'(4) SF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==5, text(1983,.92,'(5) SF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==6, text(1983,.92,'(6) SF-MS','HorizontalAlignment','left','FontSize',8); end;
    box on
    set(gca,'Layer','top');
    sub_pos = get(gca,'position'); % get subplot axis position
    set(gca,'position',sub_pos.*[1 1 1.2 1.2]) % stretch its width and height
end;
if do_export==1, 
    print(gcf,'-depsc','fig5.eps')
end


% paths
% get variables
path_df = results_df.prhat;
path_pc = results_pc.prhat;

figure;set(gcf,'PaperPosition',[0 0 7 5], ...
        'defaultaxesfontsize',7, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
tmp = [1,3,5,2,4,6];
for i=1:6
    subplot(3,2,tmp(i))
    % add nber dates
    yy = [1;0;0;1];
    xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
    col = 0.8541;
    fill(xx,yy,[col col col],'Linestyle','none');
    hold on
    if i<4, plot(months,path_df(nstart:nobs,:,i),'LineWidth',1.2,'Color',[0 0 .5]); end;
    if i>3, plot(months,path_pc(nstart:nobs,:,i-3),'LineWidth',1.2,'Color',[0 0 .5]); end;
    hold off
    axis([1978 2012 0 1])
    if i==1, text(1983,.92,'(1) DF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==2, text(1983,.92,'(2) DF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==3, text(1983,.92,'(3) DF-MS','HorizontalAlignment','left','FontSize',8); end;
    if i==4, text(1983,.92,'(4) SF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==5, text(1983,.92,'(5) SF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==6, text(1983,.92,'(6) SF-MS','HorizontalAlignment','left','FontSize',8); end;
    box on
    set(gca,'Layer','top');
    sub_pos = get(gca,'position'); % get subplot axis position
    set(gca,'position',sub_pos.*[1 1 1.2 1.2]) % stretch its width and height
end;
if do_export==1, 
    print(gcf,'-depsc','fig6.eps')
end


%%

% ml as function of q
figure;set(gcf,'PaperPosition',[0 0 7 3], ...
        'defaultaxesfontsize',7, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
for i=1:2,
    subplot(1,2,i)
    if i==1, tmp = ml50_q; end
    if i==2, tmp = mlPB_q; end
    plot([.5,.5],[0,.5],'k-','LineWidth',.7)
    hold on
    plot(tmp(:,1),tmp(:,2),'-','LineWidth',1.5,'Color',[0 0 .5])
    hold on
    plot(tmp(:,1),tmp(:,3),':','LineWidth',1.5,'Color',[0 0 .5])
    hold on
    plot(tmp(:,1),tmp(:,4),'--','LineWidth',1.5,'Color',[0 0 .5])
    hold on
    plot(tmp(:,1),tmp(:,5),'-','LineWidth',1.5,'Color',[.5 .5 .5])
    hold on
    plot(tmp(:,1),tmp(:,6),':','LineWidth',1.5,'Color',[.5 .5 .5])
    hold on
    plot(tmp(:,1),tmp(:,7),'--','LineWidth',1.5,'Color',[.5 .5 .5])
    hold off
    axis([0 1 0 .2])
    set(gca,'YTick',[0:.1:.2])
    if i==1, text(.05,.18,'Cut-off = 0.50','HorizontalAlignment','left','FontSize',8); end;
    if i==2, text(.05,.18,'Cut-off = 0.16','HorizontalAlignment','left','FontSize',8); end;
    xlabel('q','FontSize',8)
    box on
    set(gca,'Layer','top');
    sub_pos = get(gca,'position'); % get subplot axis position
    set(gca,'position',sub_pos.*[1 1 1.2 1]) % stretch its width and height
end

if do_export==1, 
    print(gcf,'-depsc','fig7.eps')
end


%%

load results02_rt

% end-of-sample results
figure;set(gcf,'PaperPosition',[0 0 7 5], ...
        'defaultaxesfontsize',7, ...
        'defaultaxeslinewidth',0.7, ...
        'defaultlinelinewidth',0.9, ...
        'defaultpatchlinewidth',0.7);
tmp = [1,3,5,2,4,6];
for i=1:6
    subplot(3,2,tmp(i))
    % add nber dates
    yy = [1;0;0;1];
    xx = [peaks(:,1),peaks(:,1),troughs(:,1),troughs(:,1)];
    col = 0.8541;
    fill(xx,yy,[col col col],'Linestyle','none');
    hold on
    plot(months,prob_rt(:,i+1),'LineWidth',1.2,'Color',[0 0 .5])
    hold off
    axis([2000 2012 0 1])
    if i==1, text(2003,.92,'(1) DF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==2, text(2003,.92,'(2) DF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==3, text(2003,.92,'(3) DF-MS','HorizontalAlignment','left','FontSize',8); end;
    if i==4, text(2003,.92,'(4) SF-SP','HorizontalAlignment','left','FontSize',8); end;
    if i==5, text(2003,.92,'(5) SF-AP','HorizontalAlignment','left','FontSize',8); end;
    if i==6, text(2003,.92,'(6) SF-MS','HorizontalAlignment','left','FontSize',8); end;
    box on
    set(gca,'Layer','top');
    sub_pos = get(gca,'position'); % get subplot axis position
    set(gca,'position',sub_pos.*[1 1 1.2 1.2]) % stretch its width and height
end;
if do_export==1, 
    print(gcf,'-depsc','fig8.eps')
end

