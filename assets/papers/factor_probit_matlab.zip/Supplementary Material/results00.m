% Dating US Business Cycles with Macro Factors
% in-sample results
% 
% Sebastian Fossati
% 10/2015


% set up
clear all
warning off all; 
format short g

% get factors
load pc_factors;
load df_factors;


%%

% NBER recession dates

% construct recessions data
NBERt = [kron((1960:2010)',ones(12,1)),kron(ones(2010-1960+1,1),(1:12)')];
nt = size(NBERt,1);
NBERt = [NBERt,zeros(nt,1)];
dates = [1960.00:1/12:2010.9167]';

% recessions dates
recessions = [((1960-1960)*12+4:(1961-1960)*12+2)';
              ((1969-1960)*12+12:(1970-1960)*12+11)';
              ((1973-1960)*12+11:(1975-1960)*12+3)';
              ((1980-1960)*12+1:(1980-1960)*12+7)';
              ((1981-1960)*12+7:(1982-1960)*12+11)';
              ((1990-1960)*12+7:(1991-1960)*12+3)';
              ((2001-1960)*12+3:(2001-1960)*12+11)';
              ((2007-1960)*12+12:(2009-1960)*12+6)' ]; 
months = size(recessions,1);
for i=1:months, NBERt(recessions(i),3) = 1; end;

% get peaks and troughs
peaks = [];
troughs = [];
temp = [0;NBERt(2:end,3)-NBERt(1:end-1,3)];
for i=1:nt-1
    if(temp(i,1)==1), peaks = [peaks;dates(i,1)];end;
    if(temp(i,1)==-1), troughs = [troughs;dates(i-1,1)];end;
end


% set up variables for regressions
yt = trimr(NBERt(:,3),2,0);
x0t = ghat; % dynamic factor
x1t = Fhat; % PC factors

dates = trimr(dates,2,0);
nobs = size(yt,1);


%%

% preliminary results

% estimate 1-factor probit models
table_mle = zeros(8,9);

% dynamic factor
tmp = probit(yt,[ones(nobs,1),x0t]);
prhat_df = tmp.yhat;
table_mle(:,1) = [  tmp.beta(1);tmp.beta(1)/tmp.tstat(1);
                    tmp.beta(2);tmp.beta(2)/tmp.tstat(2);
                    tmp.r2mf;tmp.lik;tmp.lratio;
                    1-chis_prb(tmp.lratio,tmp.nvar-1)];

% PC factors
for j=1:8,
    tmp = probit(yt,[ones(nobs,1),x1t(:,j)]);
    if j==1, prhat_pc = tmp.yhat; end
    % store MLE results
    table_mle(:,j+1) = [    tmp.beta(1);tmp.beta(1)/tmp.tstat(1);
                            tmp.beta(2);tmp.beta(2)/tmp.tstat(2);
                            tmp.r2mf;tmp.lik;tmp.lratio;
                            1-chis_prb(tmp.lratio,tmp.nvar-1)];
end


%%

% save results
disp('Dating U.S. Business Cycles with Macro Factors');
disp('Table: in-sample fit');
disp('   ');
disp(table_mle); 
disp('   ');

latex(table_mle,'nomath','%.2f');


% % Save workspace
% file = 'results00.mat';
% save(file)
