% Dating US Business Cycles with Macro Factors
% Gibbs sampler
% 
% Sebastian Fossati
% 3/11


function [mDraws,yDraws] = runProbit(y,X,iNumDraws,iNumBurn)

[nobs,k] = size(X);

% allocate storage for results
mDraws = zeros(iNumDraws,k);
yDraws = zeros(iNumDraws,nobs);
ystar = zeros(nobs,1);

% Prior hyperparameters
b0 = inv(X'*X)*X'*y;
t0 = [.5];

% initialize the parameters
bhat = b0;

% Loop for burn-in iterations: No need to store these draws
hwait = waitbar(0,'Burn-in iterations ...'); % Nice waitbar
for(j=1:iNumBurn)

    % Update the parameters of the distribution
    muY = X*bhat;
    for t=1:nobs
        term = 0;
        while (term==0);
            e = muY(t) + randn(1,1);
            if ((y(t,1)==1) & (e>=0)), ystar(t,1)=e; term=1; end;
            if ((y(t,1)==0) & (e<0)), ystar(t,1)=e; term=1; end;
        end
    end
    
    % Update the parameters of the distribution
    var = inv(X'*X);
    mu = var*(X'*ystar);
    % Draw b
    bhat = mu + chol(var)'*randn(k,1);
    
waitbar(j/iNumBurn);
end     
close(hwait);

hwait = waitbar(0,'Gibbs sampling ...'); % Nice waitbar
for(j=1:iNumDraws)

    % Update the parameters of the distribution
    muY = X*bhat;
    for t=1:nobs
        term = 0;
        while (term==0);
            e = muY(t) + randn(1,1);
            if ((y(t,1)==1) & (e>=0)), ystar(t,1)=e; term=1; end;
            if ((y(t,1)==0) & (e<0)), ystar(t,1)=e; term=1; end;
        end
    end
    
    % Update the parameters of the distribution
    var = inv(X'*X);
    mu = var*(X'*ystar);
    % Draw b
    bhat = mu + chol(var)'*randn(k,1);
    
    % Store the draws
    mDraws(j,:) = bhat'; 
    yDraws(j,:) = ystar';

waitbar(j/iNumDraws);
end
close(hwait);

thin = 20;
ind = thin*(1:(iNumDraws/thin))';
mDraws = mDraws(ind,:);
yDraws = yDraws(ind,:);

return
