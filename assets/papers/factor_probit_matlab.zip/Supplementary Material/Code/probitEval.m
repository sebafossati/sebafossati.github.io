% Dating US Business Cycles with Macro Factors
% Probit model evaluation
% 
% Sebastian Fossati
% 3/11


function [results] = probitEval(b,y,x)

% Based on code written by:
% James P. LeSage

[nobs,k] = size(x);

% compute McFadden R-squared
tmp = find(y==1); % find ones
P = length(tmp); 
cnt0 = nobs-P;
cnt1 = P;
P = P/nobs; % proportion of 1's
like0 = nobs*(P*log(P) + (1-P)*log(1-P));    % restricted likelihood
like1 = probitLike(b,y,x);            % unrestricted Likelihood
r2mf = 1-(abs(like1)/abs(like0));         % McFadden pseudo-R2 
% compute Estrella R-squared
term0 = (2/nobs)*like0;
term1 = 1/(abs(like1)/abs(like0))^term0;
r2es = 1-term1;                           % Estrella R2

% AIC and BIC
AIC = -2*like1/nobs + 2*k/nobs;
BIC = -2*like1/nobs + log(nobs)*k/nobs;

% LR stat
lratio = 2*(like1-like0);
pval = 1-chis_cdf(lratio,k-1);

% Results
results.r2mf = r2mf;
results.r2es = r2es;
results.aic = AIC;
results.bic = BIC;
results.like = like1;
results.lratio = lratio;
results.pval = pval;

return;

function [like] = probitLike(b,y,x)

i = ones(length(y),1);
cdf = norm_cdf(x*b);

tmp = find(cdf <=0);
[n1 n2] = size(tmp);
if n1 ~= 0
cdf(tmp,1) = 0.00001*ones(length(tmp),1);
end;

tmp = find(cdf >= 1);
[n1 n2] = size(tmp);
if n1 ~= 0
cdf(tmp,1) = 0.99999*ones(length(tmp),1);
end;

out = y.*log(cdf)+(i-y).*log(i-cdf);
like = sum(out);

return;