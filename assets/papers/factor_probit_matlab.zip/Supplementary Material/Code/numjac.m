function jac = numjac(f,x,varargin)
% Gets Jacobian numerically
tol = eps.^(1/3);
h = tol.*max(abs(x),1);
xh1=x+h; xh0=x-h;
h=xh1-xh0;
for j=1:length(x);
   xx = x; 
   xx(j) = xh1(j); f1=feval(f,xx,varargin{:});
   xx(j) = xh0(j); f0=feval(f,xx,varargin{:});
   jac(:,j) = (f1-f0)./h(j);
end
