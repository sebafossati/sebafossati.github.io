% Dating US Business Cycles with Macro Factors
% Gibbs sampler
% 
% Sebastian Fossati
% 3/11


function [mDraws,yDraws] = runProbitAr(y,X,iNumDraws,iNumBurn)

[nobs,k] = size(X);

% allocate storage for results
mDraws = zeros(iNumDraws,k+1);
yDraws = zeros(iNumDraws,nobs);
ystar = zeros(nobs,1);
At = zeros(nobs,1);
Bt = zeros(nobs,1);

% Prior hyperparameters
b0 = inv(X'*X)*X'*y;
t0 = [.5];

% initialize the parameters
bhat = b0;
that = t0;

% get initial values of latent variable
term = 0;
while (term==0);
    e = X(1,:)*b0 + randn(1,1);
    if ((y(1,1)==1) & (e>=0)), ystar(1,1)=e; term=1; end;
    if ((y(1,1)==0) & (e<0)), ystar(1,1)=e; term=1; end;
end
for t=2:nobs
    term = 0;
    while (term==0);
        e = X(t,:)*b0 + t0*ystar(t-1,1) + randn(1,1);
        if ((y(t,1)==1) & (e>=0)), ystar(t,1)=e; term=1; end;
        if ((y(t,1)==0) & (e<0)), ystar(t,1)=e; term=1; end;
    end
end

% Loop for burn-in iterations: No need to store these draws
hwait = waitbar(0,'Burn-in iterations ...'); % Nice waitbar
for(j=1:iNumBurn)

    % Update the parameters of the distribution
    muY = X*bhat;
    At(1,1) = muY(1,1);
    Bt(1,1) = 1;
    for t=2:nobs
        At(t,1) = muY(t,1) + that*At(t-1,1);
        Bt(t,1) = 1 + that*that*Bt(t-1,1);
    end
    
    % Draw ystar for t = T
    term = 0;
    while (term==0);
        e = muY(nobs,1) + that*ystar(nobs-1,1) + randn(1,1);
        if ((y(nobs,1)==1) & (e>=0)), ystar(nobs,1)=e; term=1; end;
        if ((y(nobs,1)==0) & (e<0)), ystar(nobs,1)=e; term=1; end;
    end
    
    % Draw ystar for t = T-1,...,2
    for t=(nobs-1):-1:2
        % get conditional mean and variance
        var = inv([Bt(t+1,1),that*that*Bt(t-1,1);that*that*Bt(t-1,1),Bt(t-1,1)]);
        mutilde = At(t,1) + that*[Bt(t,1),Bt(t-1,1)]*var*...
                [(ystar(t+1,1)-At(t+1,1));(ystar(t-1,1)-At(t-1,1))];
        sitilde = Bt(t,1) - that*that*[Bt(t,1),Bt(t-1,1)]*var*[Bt(t,1);Bt(t-1,1)];
        term = 0;
        while (term==0);
            e = mutilde + sqrt(sitilde)*randn(1,1);
            if ((y(t,1)==1) & (e>=0)), ystar(t,1)=e; term=1; end;
            if ((y(t,1)==0) & (e<0)), ystar(t,1)=e; term=1; end;
        end
    end
    
    % Draw ystar for t = 1
    mutilde = At(1,1) + that*(ystar(2,1)-At(2,1))/(1+that*that);
    sitilde = 1 - that*that/(1+that*that);
    term = 0;
    while (term==0);
        e = mutilde + sqrt(sitilde)*randn(1,1);
        if ((y(1,1)==1) & (e>=0)), ystar(1,1)=e; term=1; end;
        if ((y(1,1)==0) & (e<0)), ystar(1,1)=e; term=1; end;
    end
    
    % Update the parameters of the distribution
    ystarlag = [0;ystar(1:(nobs-1),1)];
    Wbt = ystar - that*ystarlag;
    var = inv(X'*X);
    mu = var*(X'*Wbt);
    % Draw b
    bhat = mu + chol(var)'*randn(k,1);

    % Update the parameters of the distribution
    Wtt = ystar - X*bhat;
    var = inv(ystarlag'*ystarlag);
    mu = var*(ystarlag'*Wtt);
    % Draw theta
    term = 0;
    while (term==0);
        e = mu + sqrt(var)*randn(1,1);
        if (abs(e)<1), that=e; term=1; end;
    end
    
waitbar(j/iNumBurn);
end     
close(hwait);

hwait = waitbar(0,'Gibbs sampling ...'); % Nice waitbar
for(j=1:iNumDraws)

    % Update the parameters of the distribution
    muY = X*bhat;
    At(1,1) = muY(1,1);
    Bt(1,1) = 1;
    for t=2:nobs
        At(t,1) = muY(t,1) + that*At(t-1,1);
        Bt(t,1) = 1 + that*that*Bt(t-1,1);
    end
    
    % Draw ystar for t = T
    term = 0;
    while (term==0);
        e = muY(nobs,1) + that*ystar(nobs-1,1) + randn(1,1);
        if ((y(nobs,1)==1) & (e>=0)), ystar(nobs,1)=e; term=1; end;
        if ((y(nobs,1)==0) & (e<0)), ystar(nobs,1)=e; term=1; end;
    end
    
    % Draw ystar for t = T-1,...,2
    for t=(nobs-1):-1:2
        % get conditional mean and variance
        var = inv([Bt(t+1,1),that*that*Bt(t-1,1);that*that*Bt(t-1,1),Bt(t-1,1)]);
        mutilde = At(t,1) + that*[Bt(t,1),Bt(t-1,1)]*var*...
                [(ystar(t+1,1)-At(t+1,1));(ystar(t-1,1)-At(t-1,1))];
        sitilde = Bt(t,1) - that*that*[Bt(t,1),Bt(t-1,1)]*var*[Bt(t,1);Bt(t-1,1)];
        term = 0;
        while (term==0);
            e = mutilde + sqrt(sitilde)*randn(1,1);
            if ((y(t,1)==1) & (e>=0)), ystar(t,1)=e; term=1; end;
            if ((y(t,1)==0) & (e<0)), ystar(t,1)=e; term=1; end;
        end
    end
    
    % Draw ystar for t = 1
    mutilde = At(1,1) + that*(ystar(2,1)-At(2,1))/(1+that*that);
    sitilde = 1 - that*that/(1+that*that);
    term = 0;
    while (term==0);
        e = mutilde + sqrt(sitilde)*randn(1,1);
        if ((y(1,1)==1) & (e>=0)), ystar(1,1)=e; term=1; end;
        if ((y(1,1)==0) & (e<0)), ystar(1,1)=e; term=1; end;
    end
    
    % Update the parameters of the distribution
    ystarlag = [0;ystar(1:(nobs-1),1)];
    Wbt = ystar - that*ystarlag;
    var = inv(X'*X);
    mu = var*(X'*Wbt);
    % Draw b
    bhat = mu + chol(var)'*randn(k,1);

    % Update the parameters of the distribution
    Wtt = ystar - X*bhat;
    var = inv(ystarlag'*ystarlag);
    mu = var*(ystarlag'*Wtt);
    % Draw theta
    term = 0;
    while (term==0);
        e = mu + sqrt(var)*randn(1,1);
        if (abs(e)<1), that=e; term=1; end;
    end
    
    % Store the draws
    mDraws(j,:) = [bhat',that]; 
    yDraws(j,:) = ystar';

waitbar(j/iNumDraws);
end
close(hwait);

thin = 20;
ind = thin*(1:(iNumDraws/thin))';
mDraws = mDraws(ind,:);
yDraws = yDraws(ind,:);

return
