% Sebastian Fossati
% 12/2011
% University of Alberta
% 
% PURPOSE: 


function [x1] = rest(x0)

x1 = x0;

% variances
x1(3,1) = x0(3,1)^2;

% probabilities
x1(4:5,1) = exp(x0(4:5,1))./(1+exp(x0(4:5,1)));

return;
