% Misclassification loss function


function [L] = misloss(yt,phat,cutoff,cost)

nobs = size(yt,1);
L = (1/nobs) * sum( (1-cost)*yt.*(phat<=cutoff) + cost*(1-yt).*(phat>cutoff) );

return;