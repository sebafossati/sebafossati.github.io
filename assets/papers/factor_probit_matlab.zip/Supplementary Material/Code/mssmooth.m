% Sebastian Fossati
% 12/2011
% University of Alberta
% 
% PURPOSE: Smoothing


function [pr_sm0] = mssmooth(parm1,pr_tt0,pr_tl0)

% pr_tt0 contains Pr[S_t|Y_t]
% pr_tl0 contains Pr[S_t|Y_{t-1}]

nobs = size(pr_tt0,1);

% Get parameters
prm_fnl = rest(parm1);

qpr = prm_fnl(4,1);    % Pr[St=0/St-1=0]
ppr = prm_fnl(5,1);    % Pr[St=1/St-1=1]

pr_tt1 = 1-pr_tt0;
pr_tl1 = 1-pr_tl0;

pr_sm0 = pr_tt0;       % pr_sm0 will contain Pr[S_t|Y_T]
pr_sm1 = pr_tt1;

for j=(nobs-1):-1:1
    
    % The following are P[S_t, S_t+1|Y_T]
    
    pr_sm00 = pr_sm0(j+1,1)*qpr*pr_tt0(j,1)/pr_tl0(j+1,1);
    pr_sm01 = pr_sm1(j+1,1)*(1-qpr)*pr_tt0(j,1)/pr_tl1(j+1,1);
    pr_sm10 = pr_sm0(j+1,1)*(1-ppr)*pr_tt1(j,1)/pr_tl0(j+1,1);
    pr_sm11 = pr_sm1(j+1,1)*ppr*pr_tt1(j,1)/pr_tl1(j+1,1);
    
    pr_sm0(j,1) = pr_sm00 + pr_sm01;
    pr_sm1(j,1) = pr_sm10 + pr_sm11;
    
end;

return;
