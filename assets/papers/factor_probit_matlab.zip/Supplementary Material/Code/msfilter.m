% Sebastian Fossati
% 12/2011
% University of Alberta
% 
% PURPOSE: Kalman Filter


function [dta_mat1,dta_mat2] = msfilter(parm1,yy)

nobs = size(yy,1);
dta_mat1 = zeros(nobs,1);
dta_mat2 = zeros(nobs,1);


% Get parameters
parm = rest(parm1);

mu0 = parm(1,1);
mu1 = parm(2,1);
var = parm(3,1);
qpr = parm(4,1);    % Pr[St=0/St-1=0]
ppr = parm(5,1);    % Pr[St=1/St-1=1]

emat0 = yy - mu0;
emat1 = yy - mu1;


% Initializing filter with steady-state probs
pr_ll0 = (1-ppr)/(2-ppr-qpr);
pr_ll1 = (1-qpr)/(2-ppr-qpr);

for j=1:nobs;
    % Step 1
    % pr_tlij
    pr_tl00 = qpr*pr_ll0;
    pr_tl01 = (1-qpr)*pr_ll0;
    pr_tl10 = (1-ppr)*pr_ll1;
    pr_tl11 = ppr*pr_ll1;
    % pr_tl_j
    pr_tl_0 = pr_tl00 + pr_tl10;
    pr_tl_1 = pr_tl01 + pr_tl11;
    
    % Step 2
    % fyj
    fy0 = (1/sqrt(2*pi*var))*exp(-0.5*(emat0(j,1)^2)/var);
    fy1 = (1/sqrt(2*pi*var))*exp(-0.5*(emat1(j,1)^2)/var);
    % Update probability
    fy = fy0*pr_tl_0 + fy1*pr_tl_1;
    pr_tt_0 = fy0*pr_tl_0/fy;
    pr_tt_1 = fy1*pr_tl_1/fy;
    
    pr_ll0 = pr_tt_0;
    pr_ll1 = pr_tt_1;
    
    % Store filtered probabilities
    dta_mat1(j,1) = pr_tt_0;
    dta_mat2(j,1) = pr_tl_0;
end;

return;
