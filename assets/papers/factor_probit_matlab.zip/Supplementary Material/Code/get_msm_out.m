% Dating US Business Cycles with Macro Factors
% estimate probit
% 
% Sebastian Fossati
% 12/2011

function [model0] = get_msm_out(yy0)

% Set the initial parameters
parm_in = [-1.5;0.5;0.9;4;4];

% Call the optimizer
info.hess = 'bfgs';
results = maxlik('lik_fcn',parm_in,info,yy0);

% Get filtered probabilities
[pr_tt0,junk] = msfilter(results.b,yy0);

% results
model0.phat = pr_tt0;
model0.nobs = size(yy0,1);

return;
