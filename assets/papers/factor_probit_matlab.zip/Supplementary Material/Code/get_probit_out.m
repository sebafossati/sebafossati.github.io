% Dating US Business Cycles with Macro Factors
% estimate probit
% 
% Sebastian Fossati
% 3/11

function [model0] = get_probit_out(yt,X0,rsc,iNumDraws,iNumBurn,ar)

% run sampler
if ar==1,
    [mDraws0,yDraws0] = runProbitAr_out(yt,X0,rsc,iNumDraws,iNumBurn);
else
    [mDraws0,yDraws0] = runProbit_out(yt,X0,rsc,iNumDraws,iNumBurn);
end

% effective number of draws after thinning
[iobs,nobs] = size(yDraws0);

% get estimates of the latent variable
ysmean0 = mean(yDraws0)';

% get probabilities
probs = zeros(iobs,nobs);
for i=1:iobs
    % get parameters
    beta = mDraws0(i,:)';
    % get regressors
    if ar==1,
        yslag = [0,yDraws0(i,1:(nobs-1))]';
        regX = [X0,yslag];
    else
        regX = X0;
    end
    % get index
    yshat = regX*beta;
    % get probability
    probs(i,:) = norm_cdf(yshat)';
end
% get probabilities (1)
phat0 = mean(probs)';

% results
model0.ysmean = ysmean0;
model0.phat = phat0;
model0.nobs = nobs;

return;
