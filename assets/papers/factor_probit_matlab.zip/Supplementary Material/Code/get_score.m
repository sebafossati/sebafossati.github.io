% Get Scores

function [onecol] = get_score(nber,yhat)

nobs = size(nber,1);
% Quadratic Probability Score
QPS = (1/nobs)*sum((yhat-nber).^2);
% Log Probability Score
i = ones(nobs,1);
% find zeros
temp = yhat;
tmp = find(temp<=0);
[n1 n2] = size(tmp);
if n1 ~= 0, temp(tmp,1) = 0.00001*ones(length(tmp),1); end
tmp = find(temp>=1);
[n1 n2] = size(tmp);
if n1 ~= 0, temp(tmp,1) = 0.99999*ones(length(tmp),1); end
LPS = -(1/nobs)*sum((i-nber).*log(i-temp)+nber.*log(temp));
% results
onecol = [QPS;LPS];

return