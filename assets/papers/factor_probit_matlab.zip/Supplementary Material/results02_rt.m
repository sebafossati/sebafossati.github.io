% Dating US Business Cycles with Macro Factors
% out-of-sample tables - real-time data
% 
% Sebastian Fossati
% 10/2015


% load results
clear all
load results02.mat
load out_modeldf_rt.mat
load out_modelpc_rt.mat


%% 

% get probabilities with revised data
pr_df = [   diag(trimr(results_df.prhat(:,265:end,1),84+nstart-1,0)),...
            diag(trimr(results_df.prhat(:,265:end,2),84+nstart-1,0)),...
            diag(trimr(results_df.prhat(:,265:end,3),84+nstart-1,0))];
pr_pc = [   diag(trimr(results_pc.prhat(:,265:end,1),84+nstart-1,0)),...
            diag(trimr(results_pc.prhat(:,265:end,2),84+nstart-1,0)),...
            diag(trimr(results_pc.prhat(:,265:end,3),84+nstart-1,0))];
prob = [NBERt(nstart:nobs,3),pr_df,pr_pc];

% get probabilities with real-time data
months = trimr(dates,nstart-1,0);
pr_df_rt = [    diag(trimr(results_df_rt.prhat(:,:,1),nstart-1,0)),...
                diag(trimr(results_df_rt.prhat(:,:,2),nstart-1,0)),...
                diag(trimr(results_df_rt.prhat(:,:,3),nstart-1,0))];
pr_pc_rt = [    diag(trimr(results_pc_rt.prhat(:,:,1),nstart-1,0)),...
                diag(trimr(results_pc_rt.prhat(:,:,2),nstart-1,0)),...
                diag(trimr(results_pc_rt.prhat(:,:,3),nstart-1,0))];
prob_rt = [NBERt(nstart:nobs,3),pr_df_rt,pr_pc_rt];


% QPS & LPS
QPS = zeros(2,6);
LPS = zeros(2,6);
for i=1:6, 
    tmp = get_score(prob(:,1),prob(:,i+1)); 
    QPS(1,i) = tmp(1,1);
    LPS(1,i) = tmp(2,1);
    tmp = get_score(prob_rt(:,1),prob_rt(:,i+1)); 
    QPS(2,i) = tmp(1,1);
    LPS(2,i) = tmp(2,1);
end

% out-of-sample table
table_out_1_rt = [QPS(2,:);LPS(2,:)];

    
%%

% save results
disp('Dating U.S. Business Cycles with Macro Factors');
disp('Table: Out-of-sample fit - real-time data');
disp('   ');
disp(table_out_1_rt); 
disp('   ');

latex(table_out_1_rt,'nomath','%.2f');


% Save workspace
file = 'results02_rt.mat';
save(file)
