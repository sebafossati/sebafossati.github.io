% Dating US Business Cycles with Macro Factors
% Principal components factors
% 
% Sebastian Fossati
% 09/2015


% set up
clear all
format short g


% get factors
load panel;

N = cols(macrodata);
T = rows(macrodata);

data = macrodata;
for i=1:N, 
    if vartype(i,2)>0, data(:,i) = lagn(data(:,i),vartype(i,2)); end
end

% data 1960.3-2010.12
[Fhat,macro] = get_factors(3,T,data,vartype(:,1));

% first nowcast
nstart = 229; % 1979.01

f1hat = NaN(T,(T-nstart+1));
for tn = nstart:T 
    [Ft,trash] = get_factors(3,tn,data,vartype(:,1));
    f1hat(3:tn,tn-nstart+1) = Ft(:,1);
end


% save workspace
file = 'pc_factors.mat';
save(file,'Fhat','f1hat','macro')
