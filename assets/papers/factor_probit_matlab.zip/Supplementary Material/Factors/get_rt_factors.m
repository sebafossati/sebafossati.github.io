% Dating US Business Cycles with Macro Factors
% real-time data
% 
% Sebastian Fossati
% 09/2015


% set up
clear all
format short g


% get factors
load real_time_data; 


nvint = cols(emp_vint);
T = rows(emp_vint);

% transform data
yy1 = NaN(T,nvint);
yy2 = NaN(T,nvint);
yy3 = NaN(T,nvint);
yy4 = NaN(T,nvint);
n = T-nvint+1;
for i=1:nvint;
    % (1) ip
    yy1(1:(n+i-1),i) = lagn(100*transx(ipt_vint(1:(n+i-1),i),5),2);
    % (2) manuf. sales
    yy2(1:(n+i-1),i) = lagn(100*transx(mtsr_vint(1:(n+i-1),i),5),2);
    % (3) income
    yy3(1:(n+i-1),i) = lagn(100*transx(pilt_vint(1:(n+i-1),i),5),2);
    % (4) employment
    yy4(1:(n+i-1),i) = lagn(100*transx(emp_vint(1:(n+i-1),i),5),2);
end;

% good starting values for fast convergence
parm_in = [ 0.54;0.22;0.39;0.18;
            7.69;-0.46;-0.26;-0.26;-0.18;-0.176;
           -0.45;0.61;-0.11;-0.11;
            0.35;0.89;0.76;0.93];
      
% data 1967.3-2010.12
yys = [standard(yy1(3:T,nvint)),standard(yy2(3:T,nvint)),...
        standard(yy3(3:T,nvint)),standard(yy4(3:T,nvint))];
yys = yys'; % dimension: 4xT
info.hess = 'bfgs';
results = maxlik('lik_fcn',parm_in,info,yys);

% get factor
ft_ct = kf(results.b,yys);
ghat = ft_ct(:,5);

% first nowcast
nstart = 409; % 2001.01

dfhat_rt = NaN(T,nvint);
for tn = nstart:T
    disp(tn)
    ncol = nvint-(T-tn);
    % get factors
    yys = [standard(yy1(3:tn,ncol)),standard(yy2(3:tn,ncol)),...
            standard(yy3(3:tn,ncol)),standard(yy4(3:tn,ncol))];
    yys = yys'; % dimension: 4xT
    results = maxlik('lik_fcn',results.b,info,yys);
    ft_ct = kf(results.b,yys);
    dfhat_rt(3:tn,ncol) = ft_ct(:,5);
end


% CFNAI instead of PC factor
f1hat_rt = NaN(T,nvint);
f1hat_rt(1:T,(nvint-(T-nstart)):nvint) = cfnai_vint;


% save workspace
file = 'rt_factors.mat';
save(file,'dfhat_rt','f1hat_rt')
