% Code by Serena Ng
% Modified by Sebastian Fossati

function [Fhat_T,y] = get_factors(nstart,nend,macrodata,vartype)

data = macrodata(nstart:nend,:);
tcode = vartype;

y = [];
N = cols(data);
for i=1:N;
  if tcode(i)==0; tcode(i)=1; end; 
    dum = transx(data(:,i),tcode(i));
    y = [y dum];
end;

[ehat_T,Fhat_T,lamhat_T,ve2_T]=pc_T(standard(y),8);

return
