function y = lagn(x,n)
ncol = size(x,2);
if n<0, y = [trimr(x,abs(n),0); zeros(abs(n),ncol)]; return, end 
y = [zeros(n,ncol); trimr(x,0,n)];
