function y = diffk(x,k)
[nrow ncol] = size(x);
if k==0, y = x; return, end 
y = [zeros(k,ncol); trimr(x,k,0)-trimr(lagn(x,k),k,0)];
return;