% Sebastian Fossati
% 12/2011
% University of Alberta
% 
% PURPOSE: Kalman Filter


function [out_mat] = kf(parm1,yy)

nobs = size(yy,2);

% Get SS matrices
parm = rest(parm1);
SS = ss_model(parm);
% Measurement Equation: y(t) = H*b(t) + e, e~N(0,R)
H = SS.H;
R = SS.R;
% Transition Equation: b(t) = F*b(t-1) + v, v~N(0,Q)
F = SS.F;
Q = SS.Q;

% Initial state vector
ndim = size(F,1);
BETA_LL = zeros(ndim,1);
vecP_LL = inv( eye(ndim^2)-kron(F,F) ) * vec(Q);
P_LL = reshape(vecP_LL,ndim,ndim);


% Kalman Filter 
out_mat = zeros(nobs,5);

for i = 1:nobs
    
    BETA_TL = F*BETA_LL;
    P_TL = F*P_LL*F' + Q;
    
    vt = yy(:,i) - H*BETA_TL;
    ft = H*P_TL*H' + R;
    
    BETA_TT = BETA_TL + P_TL*H'*inv(ft)*vt;
    P_TT = P_TL - P_TL*H'*inv(ft)*H*P_TL;
    
    BETA_LL = BETA_TT;
    P_LL = P_TT;
    
    out_mat(i,:) = [vt',BETA_TT(1,1)];
    
end

return;
