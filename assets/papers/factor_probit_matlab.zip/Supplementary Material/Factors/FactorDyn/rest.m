% Sebastian Fossati
% 12/2011
% University of Alberta
% 
% PURPOSE: 


function [x1] = rest(x0)

x1 = x0;

% phi1 and phi2
z1 = x0(5,1)/(1+abs(x0(5,1)));
z2 = x0(6,1)/(1+abs(x0(6,1)));
x1(5,1) = z1+z2;
x1(6,1) = -1*z1*z2;

% psi11 and psi12
z3 = x0(7,1)/(1+abs(x0(7,1)));
z4 = x0(8,1)/(1+abs(x0(8,1)));
x1(7,1) = z3+z4;
x1(8,1) = -1*z3*z4;

% psi21 and psi22
z5 = x0(9,1)/(1+abs(x0(9,1)));
z6 = x0(10,1)/(1+abs(x0(10,1)));
x1(9,1) = z5+z6;
x1(10,1) = -1*z5*z6;

% psi31 and psi32
z7 = x0(11,1)/(1+abs(x0(11,1)));
z8 = x0(12,1)/(1+abs(x0(12,1)));
x1(11,1) = z7+z8;
x1(12,1) = -1*z7*z8;

% psi41 and psi42
z9 = x0(13,1)/(1+abs(x0(13,1)));
z10 = x0(14,1)/(1+abs(x0(14,1)));
x1(13,1) = z9+z10;
x1(14,1) = -1*z9*z10;

% variances
x1(15:18,1) = x0(15:18,1).^2;

return;
