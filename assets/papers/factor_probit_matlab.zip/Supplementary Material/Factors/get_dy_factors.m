% Dating US Business Cycles with Macro Factors
% Dynamic factor
% 
% Sebastian Fossati
% 09/2015


% set up
clear all
format short g


% get factors
load coinc; % log/differenced data

N = cols(coinc);
T = rows(coinc);

data = coinc;
for i=1:N,
    vartype = 1;
    if i==2, vartype = 2; end
    data(:,i) = lagn(data(:,i),vartype);
end

% good starting values for fast convergence
% parm_in = [ 0.65;0.44;0.38;0.35;
%             2.90;-0.44;-0.07;-0.07;-0.25;-0.25;
%             -0.10;-0.10;0.10;-0.43;
%             0.57;0.76;0.87;0.88];
parm_in = [ 0.40;0.26;0.25;0.25;
            3.73;0.11;-0.09;-0.09;-0.26;-0.26;
            -0.11;-0.11;-0.12;-0.17;
            0.69;0.82;0.88;0.87];
      
% data 1960.3-2010.12
yys = standard(data(3:T,:))'; % dimension: 4xT
info.hess = 'bfgs';
results = maxlik('lik_fcn',parm_in,info,yys);

% get factor
ft_ct = kf(results.b,yys);
ghat = ft_ct(:,5);

% first nowcast
nstart = 229; % 1979.01

dfhat = NaN(T,(T-nstart+1));
for tn = nstart:T 
    disp(tn)
    % get factors
    yys = standard(data(3:tn,:))'; % dimension: 4xT
    results = maxlik('lik_fcn',results.b,info,yys);
    ft_ct = kf(results.b,yys);
    dfhat(3:tn,tn-nstart+1) = ft_ct(:,5);
end


% save workspace
file = 'df_factors.mat';
save(file,'dfhat','ghat')
